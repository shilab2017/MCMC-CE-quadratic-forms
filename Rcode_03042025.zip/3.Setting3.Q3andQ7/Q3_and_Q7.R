rm(list=ls())

# LIBRARY 
library(MASS)         # To generate multivariate normal distribution
library(CompQuadForm) # For existing methods
library(survey)       # For saddle point method
library(doParallel)
library(doRNG)
library(tmg)          # For rtmg : HMC_Sampler

source('HMC_sampler.R')
#source('Satterthwaite_vec.R')

# Setting 2
# Set initial values
q1 =  c(70, 100, 130, 165, 200, 280, 360, 420, 500, 570, 650, 1000, 1750, 2500,3000,3500,3600,3700,3800,3900,4000,4100,4200,4300,4400,4500,4650) 

# Quadratic form (Q3) in Table (1) in Duchesne and De Micheaux (2009)
lambda1 = c(10,1)
delta1 = c(0.1, 10)

h1 = c(1,1)
D1 = diag(lambda1) 

p_d1 = p_f1 = p_i1 = p_l1 = p_s1 = NA
ARE_d1 = ARE_f1 = ARE_i1 = ARE_s1 = NA
time_d1 = time_f1 = time_i1 = time_l1 = time_s1 = matrix(0, nrow=length(q1), ncol=5)

n_sum=length(h1) 

#Set parameters for HMC-CE:
sigma1 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu1 = sqrt(delta1)           # Mean of Y(multivariate normal), which is sqrt(delta)

# alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M1 = solve(sigma1)
r1 = as.vector(M1 %*% mu1)
initial1 = rep(50, n_sum) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A1 = D1
B1 = rep(0,n_sum)
C1 = (-q1)

p_HMC1 = matrix(0, nrow=length(q1), ncol=100)
p_HMC_hat1 = ARE_HMC1 = SMSE_HMC1 = rep(NA, length(q1))
time.taken1 = list()

for(k in 1:length(q1)){
  
  #Davies method
  start_d = proc.time()
  p_d1[k] = davies(q1[k], lambda=lambda1, h=h1, delta = delta1, lim=100000000, acc=1e-13)$Qq     
  time_d1[k,] = proc.time() - start_d
  
  #Farebrother method
  start_f = proc.time()
  p_f1[k] = farebrother(q=q1[k], lambda=lambda1, h=h1, delta = delta1, eps=1e-150)$Qq 
  time_f1[k,] = proc.time() - start_f
  
  #Imhof method
  start_i = proc.time()
  p_i1[k] = imhof(q=q1[k], lambda=lambda1, h=h1, delta = delta1)$Qq 
  time_i1[k,] = proc.time() - start_i
  
  #Liu method
  start_i = proc.time()
  p_l1[k] = liu(q1[k], lambda=lambda1, h=h1, delta = delta1) 
  time_i1[k,] = proc.time() - start_i
  
  #Saddle point method
  start_s = proc.time()
  p_s1[k] = pchisqsum(q1[k], lower.tail = FALSE, df = h1, a = lambda1, method = "sad")
  time_s1[k,] = proc.time() - start_s
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr1 = list(list(A1,B1,C1[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M1, r=r1, constr=constr1, q=q1[k], initial=initial1, mu=mu1, sigma=sigma1, D=D1)
  p_HMC1[k,] = res[,1]
  time.taken1[[k]] = res[,2:6]
}

p_HMC_hat1 <- rowMeans(p_HMC1)
p_HMC_hat1

p_d1
p_f1
p_i1
p_l1
p_s1

ARE_d1 = ARE_i1 = ARE_l1 = ARE_s1 = rep(NA, length(q1))
for(k in 1:length(q1)){
  ARE_d1[k] = abs(p_d1[k]-p_f1[k])/p_f1[k]
  ARE_i1[k] = abs(p_i1[k]-p_f1[k])/p_f1[k]
  ARE_l1[k] = abs(p_l1[k]-p_f1[k])/p_f1[k]
  ARE_s1[k] = abs(p_s1[k]-p_f1[k])/p_f1[k]
}


ARE_m1 <- rowMeans( abs(p_HMC1-rowMeans(p_HMC1))/rowMeans(p_HMC1) )  

for(i in 1:length(q)){
  if(p_HMC_hat1[i]>=1E-15){ARE_m1[i]=abs(p_HMC_hat1[i]-p_f1[i])/p_f1[i]}
  else{ARE_m1[i]=rowMeans(abs(p_HMC1[i,]-p_HMC_hat1[i])/p_HMC_hat1[i])}
}
ARE_m1


SRMSE_vec <- c()
for(i in 1:length(q1)){
  SRMSE_vec[i] <-  sqrt( sum( (p_HMC1[i,] - mean(p_HMC1[i,])*rep(1,length=100))^2)/100) /mean(p_HMC1[i,])
}
SRMSE_vec
# [1] 0.02121013 0.10721720 0.05986324 0.01706477 0.02222455 0.01675636 0.01685887 0.01839227 0.01837727 0.02393539 0.02776991
# [12] 0.03065636 0.03062222 0.03467272 0.03866284 0.04015332 0.03888026 0.04363161 0.04658255 0.04965518 0.05204423 0.06264949


time_avg_m1 <- as.numeric()
time_sd_m1 <- as.numeric()
for(i in 1:length(q1)){
  time_avg_m1[i] <- mean(time.taken1[[i]][,3])
  time_sd_m1[i] <- sd(time.taken1[[i]][,3])
}



#------------------------------------------------------------------

Table1 <- cbind(q1, p_d1, ARE_d1, time_d1[,3]
                , p_f1,  time_f1[,3]
                , p_i1, ARE_i1, time_i1[,3]
                , p_l1, ARE_l1, time_l1[,3]
                , p_s1, ARE_s1, time_s1[,3]
                , p_HMC_hat1, ARE_m1, SRMSE_vec, time_avg_m1, time_sd_m1
)


write.csv(Table1,'Table.Non-Central Chi-squared(settingQ3)FINAL.csv')


save.image(file="MCMC-CE_Q3TableFINAL.RData")

#_____________________________________________________________________________________________________
# Setting 2
# Set initial values
q2 =  c(8, 13, 19, 25, 34,43,52,60,65,70,75,80,90,100,110,118, 125, 175, 250,375,475) #critical values

# Quadratic form (Q7) in Table (1) in Duchesne and De Micheaux (2009)
lambda2 = c(1, 1, 0.7^6) # the first term of Q7 is split into 2 equal terms
delta2 = c(0.1,0.1,10) # # the first term of Q7 is split into 2 equal terms
h2 = c(1,1,1)

h2 = c(1,1,1)
D2 = diag(lambda2) 

p_d2 = p_f2 = p_i2 = p_l2 = p_s2 = NA
ARE_d2 = ARE_f2 = ARE_i2 = ARE_s2 = NA
time_d2 = time_f2 = time_i2 = time_l2 = time_s2 = matrix(0, nrow=length(q2), ncol=5)

n_sum=length(h2) 

#Set parameters for HMC-CE:
sigma2 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu2 = sqrt(delta2)           # Mean of Y(multivariate normal), which is sqrt(delta)

# alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M2 = solve(sigma2)
r2 = as.vector(M2 %*% mu2)
initial2 = rep(50, n_sum) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A2 = D2
B2 = rep(0,n_sum)
C2 = (-q2)

p_HMC2 = matrix(0, nrow=length(q2), ncol=100)
p_HMC_hat2 = ARE_HMC2 = SMSE_HMC2 = rep(NA, length(q2))
time.taken2 = list()

for(k in 1:length(q2)){
  
  #Davies method
  start_d = proc.time()
  p_d2[k] = davies(q2[k], lambda=lambda2, h=h2, delta = delta2, lim=100000000, acc=1e-13)$Qq     
  time_d2[k,] = proc.time() - start_d

  #Farebrother method
  start_f = proc.time()
  p_f2[k] = farebrother(q=q2[k], lambda=lambda2, h=h2, delta = delta2, eps=1e-150)$Qq 
  time_f2[k,] = proc.time() - start_f
  
  #Imhof method
  start_i = proc.time()
  p_i2[k] = imhof(q=q2[k], lambda=lambda2, h=h2, delta = delta2)$Qq 
  time_i2[k,] = proc.time() - start_i
  
  #Liu method
  start_i = proc.time()
  p_l2[k] = liu(q2[k], lambda=lambda2, h=h2, delta = delta2) 
  time_i2[k,] = proc.time() - start_i
  
  #Saddle point method
  start_s = proc.time()
  p_s2[k] = pchisqsum(q2[k], lower.tail = FALSE, df = h2, a = lambda2, method = "sad")
  time_s2[k,] = proc.time() - start_s
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr2 = list(list(A2,B2,C2[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M2, r=r2, constr=constr2, q=q2[k], initial=initial2, mu=mu2, sigma=sigma2, D=D2)
  p_HMC2[k,] = res[,1]
  time.taken2[[k]] = res[,2:6]
}

p_HMC_hat2 <- rowMeans(p_HMC2)
p_HMC_hat2

p_d2
p_f2
p_i2
p_l2
p_s2

ARE_d2 = ARE_i2 = ARE_l2 = ARE_s2 = rep(NA, length(q2))
for(k in 1:length(q2)){
  ARE_d2[k] = abs(p_d2[k]-p_f2[k])/p_f2[k]
  ARE_i2[k] = abs(p_i2[k]-p_f2[k])/p_f2[k]
  ARE_l2[k] = abs(p_l2[k]-p_f2[k])/p_f2[k]
  ARE_s2[k] = abs(p_s2[k]-p_f2[k])/p_f2[k]
}


ARE_m2 <- rowMeans( abs(p_HMC2-rowMeans(p_HMC2))/rowMeans(p_HMC2) )  

for(i in 1:length(q)){
  if(p_HMC_hat2[i]>=1E-15){ARE_m2[i]=abs(p_HMC_hat2[i]-p_f2[i])/p_f2[i]}
  else{ARE_m2[i]=rowMeans(abs(p_HMC2[i,]-p_HMC_hat2[i])/p_HMC_hat2[i])}
}
ARE_m2


SRMSE_vec <- c()
for(i in 1:length(q2)){
  SRMSE_vec[i] <-  sqrt( sum( (p_HMC2[i,] - mean(p_HMC2[i,])*rep(1,length=100))^2)/100) /mean(p_HMC2[i,])
}
SRMSE_vec
# [1] 0.02121013 0.10721720 0.05986324 0.01706477 0.02222455 0.01675636 0.01685887 0.01839227 0.01837727 0.02393539 0.02776991
# [12] 0.03065636 0.03062222 0.03467272 0.03866284 0.04015332 0.03888026 0.04363161 0.04658255 0.04965518 0.05204423 0.06264949


time_avg_m2 <- as.numeric()
time_sd_m2 <- as.numeric()
for(i in 1:length(q2)){
  time_avg_m2[i] <- mean(time.taken2[[i]][,3])
  time_sd_m2[i] <- sd(time.taken2[[i]][,3])
}



#------------------------------------------------------------------

Table2 <- cbind(q2, p_d2, ARE_d2, time_d2[,3]
                , p_f2,  time_f2[,3]
                , p_i2, ARE_i2, time_i2[,3]
                , p_l2, ARE_l2, time_l2[,3]
                , p_s2, ARE_s2, time_s2[,3]
                , p_HMC_hat2, ARE_m2, SRMSE_vec, time_avg_m2, time_sd_m2
)


write.csv(Table2,'Table.Non-Central Chi-squared(settingQ7)FINAL.csv')


save.image(file="MCMC-CE_Q7TableFINAL.RData")

#___________________________________________________________________________________________
# ---- create excel file with multiple sheets ----------------------------------------------

df1 <- as.data.frame(cbind(q1, p_f1, p_d1, ARE_d1,p_i1, ARE_i1,p_l1, ARE_l1,p_s1, ARE_s1,p_HMC_hat1, ARE_m1))
                           
colnames(df1) <- c("q","p_Farebrother","p_Davies","ARE_Davies",		
                   "p_Imhof",	"ARE_Imhof",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df1, file = 'Q3.csv') 

df2 <- as.data.frame(cbind(q2, p_f2, p_d2, ARE_d2,p_i2, ARE_i2,p_l2, ARE_l2,p_s2, ARE_s2,p_HMC_hat2, ARE_m2)) 

colnames(df2) <- c("q","p_Farebrother","p_Davies","ARE_Davies",		
                   "p_Imhof",	"ARE_Imhof",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df2, file = 'Q7.csv') 


library(openxlsx)

Q3Q7_dataset_names <- list('Q3' = df1, 'Q7' = df2)

#export each data frame to separate sheets in same Excel file
openxlsx::write.xlsx(Q3Q7_dataset_names, file = 'Q3_and_Q7.xlsx') 

save.image(file="Q3_and_Q7.RData")

#________ PLOTTING______________________________________________________________