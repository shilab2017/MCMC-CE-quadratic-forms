#This script generates the results of the 1st simulation experiment of Shi et al "Accurate and Efficient Calculation of Small P-Values with the Cross-Entropy Method"
#This experiment uses the MCMC-CE algorithm to calculate p-values of chi^2 distributions
#and compare the performance with Davies's method, Farebrother's method, Imhof's method
#notation: chi^2(nu,delta), nu is degrees of freedom, delta is the non-central parameter
#Since we used central chi-squared distributions, therefore delta is all 0's, but needs to be given

rm(list=ls())
### add 04/10/2024
setwd("D:\\Dissertation_Vy\\Dissertation_Vy\\previous_results\\Simulation Study\\R codes\\Final codes")### add 04/10/2024


#load all packages used
library(tmg)
library(CompQuadForm)
library(mvtnorm)
library(doParallel)
library(doRNG)
library(bigQF)
library(survey)
library(matrixStats)

#source the script for the Hamiltonian Monte Carlo sampler
source('HMC_sampler.R')

#two functions to calculate absolute relative error and standardized mean squared error
cal_ARE = function(p_estimate, p) #absolute relative error
{
  return(abs(rowMeans(p_estimate)-p)/p)
}

cal_SMSE = function(p_estimate, p) #the standardized mean squared error (SMSE) - MSE is too small to use
{
  return( sqrt(rowSums((p_estimate-p)^2) / length(p_estimate))/p )
}

########################################################################################################
#Setting 1: chi^2(nu=5,delta=0)
nu1=5
delta1=0

lambda1 = rep(1, times=nu1) #the weights in the linear combination of chi_squares 
D1 = diag(lambda1)

q1 =  seq(30, 480, by=17) #critical values
p_real1 = pchisq(q1, df=nu1, lower.tail=F) #true tail probability

p_d1 = p_f1 = p_i1 = p_s1 = NA
ARE_d1 = ARE_f1 = ARE_i1 = ARE_s1 = NA
time_d1 = time_f1 = time_i1 = time_s1 = matrix(0, nrow=length(q1), ncol=5)

p_l1 = NA
ARE_l1 = NA

#Below are parameters for HMC-CE:
sigma1 = diag(rep(1, nu1)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu1 = rep(0, nu1) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M1 = solve(sigma1)
r1 = as.vector(M1 %*% mu1)

initial1 = rep(50, nu1) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A1 = D1
B1 = rep(0,nu1)
C1 = (-q1)

p_HMC1 = matrix(0, nrow=length(q1), ncol=100)
p_HMC_hat1 = ARE_HMC1 = SMSE_HMC1 = NA
time.taken1 = list()

for(k in 1:length(q1))
{
  #LTZ method
  p_l1[k] = liu(q=q1[k], lambda=1, h=nu1)
  ARE_l1[k] = abs(p_l1[k]-p_real1[k])/p_real1[k]  
  
  # #Davies method
  # start_d = proc.time()
  # p_d1[k] = davies(q=q1[k], lambda=1, h=nu1, acc = 1e-16, lim = 5e+07)$Qq #we have tried different lim and acc - results do not change
  # time_d1[k,] = proc.time() - start_d
  # ARE_d1[k] = abs(p_d1[k]-p_real1[k])/p_real1[k]
  # 
  # #Farebrother method
  # start_f = proc.time()
  # p_f1[k] = farebrother(q=q1[k], lambda=1, h=nu1, eps=1e-150)$Qq #we have tried different eps - results do not change
  # time_f1[k,] = proc.time() - start_f
  # ARE_f1[k] = abs(p_f1[k]-p_real1[k])/p_real1[k]
  # 
  # #Imhof method
  # start_i = proc.time()
  # p_i1[k] = imhof(q=q1[k], lambda=1, h=nu1)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  # time_i1[k,] = proc.time() - start_i
  # ARE_i1[k] = abs(p_i1[k]-p_real1[k])/p_real1[k]
  # 
  # #Saddle point method
  # start_i = proc.time()
  # p_s1[k] = pchisqsum(q1[k], lower.tail = FALSE, df = lambda1, a = lambda1, method = "sad") 
  # time_s1[k,] = proc.time() - start_i
  # ARE_s1[k] = abs(p_s1[k]-p_real1[k])/p_real1[k]
  # 
  # 
  # #MCMC-CE
  # #the quadratic constraint of HMC for multivariate gaussian
  # constr1 = list(list(A1,B1,C1[k]))
  # 
  # set.seed(2022)
  # 
  # res = HMC_sampler(M=M1, r=r1, constr=constr1, q=q1[k], initial=initial1, mu=mu1, sigma=sigma1)
  # 
  # p_HMC1[k,] = res[,1]
  # 
  # time.taken1[[k]] = res[,2:6]
}

ARE_HMC1 = cal_ARE(p_HMC1,p_real1)

df1 <- as.data.frame(cbind(q1,p_real1,p_d1,ARE_d1,p_f1,ARE_f1,p_i1,ARE_i1,p_s1,ARE_s1,rowMeans(p_HMC1),ARE_HMC1)) # add 04/10/2024
colnames(df1) <- c("q","p","p_Davies","ARE_Davies","p_Farebrother","ARE_Farebrother","p_Imhof","ARE_Imhof","p_Saddlepoint","ARE_Saddlepoint","p_MCMC-CE","ARE_MCMC-CE")
#library(openxlsx)
write.csv(df1, file = 'cen_5.csv') # add 04/10/2024

save.image(file="MCMC-CE_E5_new.RData") # add 04/10/2024
########################################################################################################

#Setting 2: chi^2(nu=20,delta=0)
nu2=20
delta2=0

lambda2 = rep(1, times=nu2) #the weights in the linear combination of chi_squares 
D2 = diag(lambda2)

q2 =  seq(55,545,by=15) #critical values
p_real2 = pchisq(q2, df=nu2, lower.tail=F) #true tail probability

p_d2 = p_f2 = p_i2 = p_s2 = NA
ARE_d2 = ARE_f2 = ARE_i2 = ARE_s2 = NA
time_d2 = time_f2 = time_i2 = time_s2 = matrix(0, nrow=length(q2), ncol=5)

#Below are parameters for HMC-CE:
sigma2 = diag(rep(1, nu2)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu2 = rep(0, nu2) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M2 = solve(sigma2)
r2 = as.vector(M2 %*% mu2)

initial2 = rep(50, nu2) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A2 = D2
B2 = rep(0,nu2)
C2 = (-q2)

p_HMC2 = matrix(0, nrow=length(q2), ncol=100)
p_HMC_hat2 = ARE_HMC2 = SMSE_HMC2 = NA
time.taken2 = list()

for(k in 1:length(q2))
{
  #Davies method
  start_d = proc.time()
  p_d2[k] = davies(q=q2[k], lambda=1, h=nu2, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d2[k,] = proc.time() - start_d
  ARE_d2[k] = abs(p_d2[k]-p_real2[k])/p_real2[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f2[k] = farebrother(q=q2[k], lambda=1, h=nu2, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f2[k,] = proc.time() - start_f
  ARE_f2[k] = abs(p_f2[k]-p_real2[k])/p_real2[k]
  
  #Imhof method
  start_i = proc.time()
  p_i2[k] = imhof(q=q2[k], lambda=1, h=nu2)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i2[k,] = proc.time() - start_i
  ARE_i2[k] = abs(p_i2[k]-p_real2[k])/p_real2[k]
  
  #Saddle point method
  start_i = proc.time()
  p_s2[k] = pchisqsum(q2[k], lower.tail = FALSE, df = lambda2, a = lambda2, method = "sad") 
  time_s2[k,] = proc.time() - start_i
  ARE_s2[k] = abs(p_s2[k]-p_real2[k])/p_real2[k]
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr2 = list(list(A2,B2,C2[k]))
  
  set.seed(2022)
  
  res = HMC_sampler(M=M2, r=r2, constr=constr2, q=q2[k], initial=initial2, mu=mu2, sigma=sigma2)
  
  p_HMC2[k,] = res[,1]
  
  time.taken2[[k]] = res[,2:6]
}


#save.image(file="MCMC-CE_E20.RData")

ARE_HMC2 = cal_ARE(p_HMC2,p_real2)

df2 <- as.data.frame(cbind(q2,p_real2,p_d2,ARE_d2,p_f2,ARE_f2,p_i2,ARE_i2,p_s2,ARE_s2,rowMeans(p_HMC2),ARE_HMC2)) # add 04/10/2024
colnames(df2) <- c("q","p","p_Davies","ARE_Davies","p_Farebrother","ARE_Farebrother","p_Imhof","ARE_Imhof","p_Saddlepoint","ARE_Saddlepoint","p_MCMC-CE","ARE_MCMC-CE")
#library(openxlsx)
write.csv(df2, file = 'cen_20.csv') # add 04/10/2024

save.image(file="MCMC-CE_E20_new.RData") # add 04/10/2024

########################################################################################################
#Setting 3: chi^2(nu=50,delta=0)
nu3=50
delta3=0

lambda3 = rep(1, times=nu3) #the weights in the linear combination of chi_squares 
D3 = diag(lambda3)

q3 =  seq(100, 635, by=15) #critical values
p_real3 = pchisq(q3, df=nu3, lower.tail=F) #true tail probability
p_real3

p_d3 = p_f3 = p_i3 = p_s3 = NA
ARE_d3 = ARE_f3 = ARE_i3 = ARE_s3 = NA
time_d3 = time_f3 = time_i3 = time_s3 = matrix(0, nrow=length(q3), ncol=5)

#Below are parameters for HMC-CE:
sigma3 = diag(rep(1, nu3)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu3 = rep(0, nu3) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M3 = solve(sigma3)
r3 = as.vector(M3 %*% mu3)

initial3 = rep(50, nu3) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A3 = D3
B3 = rep(0,nu3)
C3 = (-q3)

p_HMC3 = matrix(0, nrow=length(q3), ncol=100)
p_HMC_hat3 = ARE_HMC3 = SMSE_HMC3 = NA
time.taken3 = list()

for(k in 1:length(q3))
{
  #Davies method
  start_d = proc.time()
  p_d3[k] = davies(q=q3[k], lambda=1, h=nu3, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d3[k,] = proc.time() - start_d
  ARE_d3[k] = abs(p_d3[k]-p_real3[k])/p_real3[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f3[k] = farebrother(q=q3[k], lambda=1, h=nu3, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f3[k,] = proc.time() - start_f
  ARE_f3[k] = abs(p_f3[k]-p_real3[k])/p_real3[k]
  
  #Imhof method
  start_i = proc.time()
  p_i3[k] = imhof(q=q3[k], lambda=1, h=nu3)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i3[k,] = proc.time() - start_i
  ARE_i3[k] = abs(p_i3[k]-p_real3[k])/p_real3[k]
  
  #Saddle point method
  start_i = proc.time()
  p_s3[k] = pchisqsum(q3[k], lower.tail = FALSE, df = lambda3, a = lambda3, method = "sad") 
  time_s3[k,] = proc.time() - start_i
  ARE_s3[k] = abs(p_s3[k]-p_real3[k])/p_real3[k]
  
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr3 = list(list(A3,B3,C3[k]))
  
  set.seed(2022)
  
  res = HMC_sampler(M=M3, r=r3, constr=constr3, q=q3[k], initial=initial3, mu=mu3, sigma=sigma3)
  
  p_HMC3[k,] = res[,1]
  
  time.taken3[[k]] = res[,2:6]
}



#save.image(file="MCMC-CE_E50.RData")

ARE_HMC3 = cal_ARE(p_HMC3,p_real3)

df3 <- as.data.frame(cbind(q3,p_real3,p_d3,ARE_d3,p_f3,ARE_f3,p_i3,ARE_i3,p_s3,ARE_s3,rowMeans(p_HMC3),ARE_HMC3)) # add 04/10/2024
colnames(df3) <- c("q","p","p_Davies","ARE_Davies","p_Farebrother","ARE_Farebrother","p_Imhof","ARE_Imhof","p_Saddlepoint","ARE_Saddlepoint","p_MCMC-CE","ARE_MCMC-CE")
#library(openxlsx)
write.csv(df3, file = 'cen_50.csv') # add 04/10/2024

save.image(file="MCMC-CE_E50_new.RData") # add 04/10/2024

########################################################################################################
#Setting 4: chi^2(nu=100,delta=0)
nu4=100
delta4=0

lambda4 = rep(1, times=nu4) #the weights in the linear combination of chi_squares 
D4 = diag(lambda4)

q4 =  seq(170, 750, by=20) #critical values
p_real4 = pchisq(q4, df=nu4, lower.tail=F) #true tail probability
p_real4

p_d4 = p_f4 = p_i4 = p_s4 = NA
ARE_d4 = ARE_f4 = ARE_i4 = ARE_s4 = NA
time_d4 = time_f4 = time_i4 = time_s4 = matrix(0, nrow=length(q4), ncol=5)

#Below are parameters for HMC-CE:
sigma4 = diag(rep(1, nu4)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu4 = rep(0, nu4) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M4 = solve(sigma4)
r4 = as.vector(M4 %*% mu4)

initial4 = rep(50, nu4) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A4 = D4
B4 = rep(0,nu4)
C4 = (-q4)

p_HMC4 = matrix(0, nrow=length(q4), ncol=100)
p_HMC_hat4 = ARE_HMC4 = SMSE_HMC4 = NA
time.taken4 = list()
  
for(k in 1:length(q4))
{
  #Davies method
  start_d = proc.time()
  p_d4[k] = davies(q=q4[k], lambda=1, h=nu4, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d4[k,] = proc.time() - start_d
  ARE_d4[k] = abs(p_d4[k]-p_real4[k])/p_real4[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f4[k] = farebrother(q=q4[k], lambda=1, h=nu4, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f4[k,] = proc.time() - start_f
  ARE_f4[k] = abs(p_f4[k]-p_real4[k])/p_real4[k]
  
  #Imhof method
  start_i = proc.time()
  p_i4[k] = imhof(q=q4[k], lambda=1, h=nu4)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i4[k,] = proc.time() - start_i
  ARE_i4[k] = abs(p_i4[k]-p_real4[k])/p_real4[k]
  
  #Saddle point method
  start_i = proc.time()
  p_s4[k] = pchisqsum(q4[k], lower.tail = FALSE, df = lambda4, a = lambda4, method = "sad") 
  time_s4[k,] = proc.time() - start_i
  ARE_s4[k] = abs(p_s4[k]-p_real4[k])/p_real4[k]
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr4 = list(list(A4,B4,C4[k]))
  
  set.seed(2022)
  
  res = HMC_sampler(M=M4, r=r4, constr=constr4, q=q4[k], initial=initial4, mu=mu4, sigma=sigma4)
  
  p_HMC4[k,] = res[,1]
  
  time.taken4[[k]] = res[,2:6]
  
}

ARE_HMC4 = cal_ARE(p_HMC4,p_real4)

save.image(file="MCMC-CE_E100.RData")

save.image(file="MCMC-CE_E100_new.RData") # add 04/10/2024
df4 <- as.data.frame(cbind(q4,p_real4,p_d4,ARE_d4,p_f4,ARE_f4,p_i4,ARE_i4,p_s4,ARE_s4,rowMeans(p_HMC4),ARE_HMC4)) # add 04/10/2024
colnames(df4) <- c("q","p","p_Davies","ARE_Davies","p_Farebrother","ARE_Farebrother","p_Imhof","ARE_Imhof","p_Saddlepoint","ARE_Saddlepoint","p_MCMC-CE","ARE_MCMC-CE")
#library(openxlsx)
write.csv(df4, file = 'cen_100.csv') # add 04/10/2024


########################################################################################################
#Setting 5: chi^2(nu=200,delta=0)
nu5=200
delta5=0

lambda5 = rep(1, times=nu5) #the weights in the linear combination of chi_squares
D5 = diag(lambda5)

q5 =  seq(290, 980, by=25) #critical values
p_real5 = pchisq(q5, df=nu5, lower.tail=F) #true tail probability
p_real5


p_d5 = p_f5 = p_i5 = p_s5 = NA
ARE_d5 = ARE_f5 = ARE_i5 = ARE_s5 = NA
time_d5 = time_f5 = time_i5 = time_s5 = matrix(0, nrow=length(q5), ncol=5)

#Below are parameters for HMC-CE:
sigma5 = diag(rep(1, nu5)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu5 = rep(0, nu5)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M5 = solve(sigma5)
r5 = as.vector(M5 %*% mu5)

initial5 = rep(50, nu5) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A5 = D5
B5 = rep(0,nu5)
C5 = (-q5)

p_HMC5 = matrix(0, nrow=length(q5), ncol=100)
p_HMC_hat5 = ARE_HMC5 = SMSE_HMC5 = NA
time.taken5 = list()

for(k in 1:length(q5))
{
  #Davies method
  start_d = proc.time()
  p_d5[k] = davies(q=q5[k], lambda=1, h=nu5, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d5[k,] = proc.time() - start_d
  ARE_d5[k] = abs(p_d5[k]-p_real5[k])/p_real5[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f5[k] = farebrother(q=q5[k], lambda=1, h=nu5, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f5[k,] = proc.time() - start_f
  ARE_f5[k] = abs(p_f5[k]-p_real5[k])/p_real5[k]
  
  #Imhof method
  start_i = proc.time()
  p_i5[k] = imhof(q=q5[k], lambda=1, h=nu5)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i5[k,] = proc.time() - start_i
  ARE_i5[k] = abs(p_i5[k]-p_real5[k])/p_real5[k]
  
  #Saddle point method
  start_i = proc.time()
  p_s5[k] = pchisqsum(q5[k], lower.tail = FALSE, df = lambda5, a = lambda5, method = "sad")
  time_s5[k,] = proc.time() - start_i
  ARE_s5[k] = abs(p_s5[k]-p_real5[k])/p_real5[k]
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr5 = list(list(A5,B5,C5[k]))
  
  set.seed(2022)
  
  res = HMC_sampler(M=M5, r=r5, constr=constr5, q=q5[k], initial=initial5, mu=mu5, sigma=sigma5)
  
  p_HMC5[k,] = res[,1]
  
  time.taken5[[k]] = res[,2:6]
  
}

#save.image(file="MCMC-CE_E200.RData")
ARE_HMC5 = cal_ARE(p_HMC5,p_real5)

df5 <- as.data.frame(cbind(q5,p_real5,p_d5,ARE_d5,p_f5,ARE_f5,p_i5,ARE_i5,p_s5,ARE_s5,rowMeans(p_HMC5),ARE_HMC5)) # add 04/10/2024
colnames(df5) <- c("q","p","p_Davies","ARE_Davies","p_Farebrother","ARE_Farebrother","p_Imhof","ARE_Imhof","p_Saddlepoint","ARE_Saddlepoint","p_MCMC-CE","ARE_MCMC-CE")
#library(openxlsx)
write.csv(df5, file = 'cen_200.csv') # add 04/10/2024

save.image(file="MCMC-CE_E200_new.RData") # add 04/10/2024



########################################################################################################
#Setting 6: chi^2(nu=250,delta=0)
nu6=250
delta6=0

lambda6 = rep(1, times=nu6) #the weights in the linear combination of chi_squares
D6 = diag(lambda6)

q6 =  seq(346, 1060, by=23) #critical values
p_real6 = pchisq(q6, df=nu6, lower.tail=F) #true tail probability

p_d6 = p_f6 = p_i6 = p_s6 = NA
ARE_d6 = ARE_f6 = ARE_i6 = ARE_s6 = NA
time_d6 = time_f6 = time_i6 = time_s6 = matrix(0, nrow=length(q6), ncol=5)

#Below are parameters for HMC-CE:
sigma6 = diag(rep(1, nu6)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu6 = rep(0, nu6)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M6 = solve(sigma6)
r6 = as.vector(M6 %*% mu6)

initial6 = rep(50, nu6) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A6 = D6
B6 = rep(0,nu6)
C6 = (-q6)

p_HMC6 = matrix(0, nrow=length(q6), ncol=100)
p_HMC_hat6 = ARE_HMC6 = SMSE_HMC6 = NA
time.taken6 = list()

for(k in 1:length(q6))
{  
  #Davies method
  start_d = proc.time()
  p_d6[k] = davies(q=q6[k], lambda=1, h=nu6, lim=50000, acc=1e-100)$Qq 
  time_d6[k,] = proc.time() - start_d
  ARE_d6[k] = abs(p_d6[k]-p_real6[k])/p_real6[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f6[k] = farebrother(q=q6[k], lambda=1, h=nu6, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f6[k,] = proc.time() - start_f
  ARE_f6[k] = abs(p_f6[k]-p_real6[k])/p_real6[k]
  
  #Imhof method
  start_i = proc.time()
  p_i6[k] = imhof(q=q6[k], lambda=1, h=nu6)$Qq 
  time_i6[k,] = proc.time() - start_i
  ARE_i6[k] = abs(p_i6[k]-p_real6[k])/p_real6[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s6[k] = pchisqsum(q6[k], lower.tail = FALSE, df = lambda6, a = lambda6, method = "sad")
  time_s6[k,] = proc.time() - start_s
  ARE_s6[k] = abs(p_s6[k]-p_real6[k])/p_real6[k]
  
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr6 = list(list(A6,B6,C6[k]))
  
  set.seed(2022)
  
  res = HMC_sampler(M=M6, r=r6, constr=constr6, q=q6[k], initial=initial6, mu=mu6, sigma=sigma6)
  
  p_HMC6[k,] = res[,1]
  
  time.taken6[[k]] = res[,2:6]
  
}

#save.image(file="MCMC-CE_E250.RData")
ARE_HMC6 = cal_ARE(p_HMC6,p_real6)

df6 <- as.data.frame(cbind(q6,p_real6,p_d6,ARE_d6,p_f6,ARE_f6,p_i6,ARE_i6,p_s6,ARE_s6,rowMeans(p_HMC6),ARE_HMC6)) # add 04/10/2024
colnames(df6) <- c("q","p","p_Davies","ARE_Davies","p_Farebrother","ARE_Farebrother","p_Imhof","ARE_Imhof","p_Saddlepoint","ARE_Saddlepoint","p_MCMC-CE","ARE_MCMC-CE")
#library(openxlsx)
write.csv(df6, file = 'cen_250.csv') # add 04/10/2024

save.image(file="MCMC-CE_E250_new.RData") # add 04/10/2024

save.image(file="MCMC-CE_centralchisq.RData") # add 04/10/2024

#-------------------------------------------------------------------------------------------
# ---- create excel file with multiple sheets ----------------------------------------------
library(openxlsx)

dataset_names <- list('m=5' = df1, 'm=20' = df2, 'm=50' = df3, 'm=100' = df4, 'm=200' = df5,'m=250' = df6)

#export each data frame to separate sheets in same Excel file
openxlsx::write.xlsx(dataset_names, file = 'centralchisq.xlsx') 
#-------------------------------------------------------------------------------------------
#--- making FIGURE 1 -----------------------------------------------------------------------
load("D:\\Dissertation_Vy\\Dissertation_Vy\\previous_results\\Simulation Study\\R codes\\Final codes\\MCMC-CE_centralchisq.RData")


#png("Figure1.png", width=17*3.3, height=22.5*3.3, units="cm", res=300)
png("Figure1final.png", width=17*3.3, height=22.5*3.3, units="cm", res=300)

margin=c(4,4,6,2)
par(mfrow=c(3,2), omi=c(0.5,0.5,0,0), mar=margin)                      #set the size of the outer margins
#m = matrix(1:6, nrow=3,ncol=2, byrow = TRUE)
#layout(mat = m, heights = c(0.5,0.5))

#rank = 5 -----------------------------------------------
p_m1 = rowSums(p_HMC1)/100
ARE_m1 = abs(p_m1 - p_real1) / p_real1

#saddle point
y_min = floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real1)))
x_max = ceiling(max(-log10(p_real1)))

plot(-log10(p_real1), log10(ARE_s1), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real1), log10(ARE_s1), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real1), log10(ARE_m1), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real1), log10(ARE_m1), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real1), log10(ARE_d1), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real1), log10(ARE_d1), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real1), log10(ARE_f1), col = "green", cex = 2, pch = 2)
lines(-log10(p_real1), log10(ARE_f1), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real1), log10(ARE_i1), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real1), log10(ARE_i1), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real1), label = ceiling(-log10(p_real1)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='A', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("m")*bold(" = 5")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

#rank = 20 -----------------------------------------------
p_m2 = rowSums(p_HMC2)/100
ARE_m2 = abs(p_m2 - p_real2) / p_real2

#saddle point
y_min = floor(log10(min(c(ARE_f2, ARE_d2, ARE_s2, ARE_m2, ARE_i2)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real2)))
x_max = ceiling(max(-log10(p_real2)))

plot(-log10(p_real2), log10(ARE_s2), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real2), log10(ARE_s2), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real2), log10(ARE_m2), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real2), log10(ARE_m2), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real2), log10(ARE_d2), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real2), log10(ARE_d2), col = "purple", lwd = 2, lty = 4)
#ind_d2 = min(which(ARE_d2>0.999))
#points(-log10(p_real2)[ind_d2], log10(ARE_d2[ind_d2]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real2), log10(ARE_f2), col = "green", cex = 2, pch = 2)
lines(-log10(p_real2), log10(ARE_f2), col = "green", lwd = 2, lty = 4)
#ind_f2 = min(which(ARE_f2>0.999))
#points(-log10(p_real2)[ind_f2], log10(ARE_f2[ind_f2])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real2), log10(ARE_i2), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real2), log10(ARE_i2), col = "orange", lwd = 2, lty = 4)
#ind_i2 = min(which(ARE_i2>0.999))
#points(-log10(p_real2)[ind_i2], log10(ARE_i2[ind_i2]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real2), label = ceiling(-log10(p_real2)), 
     font=2,
     cex.axis = 1.25)

y_min = floor(log10(min(c(ARE_f2, ARE_d2, ARE_s2, ARE_m2, ARE_i2)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='B', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("m")*bold(" = 20")), side=3, line=1, font=2, cex=3)

################################################################################
#rank = 50
p_m3 = rowSums(p_HMC3)/100
ARE_m3 = abs(p_m3 - p_real3) / p_real3

#saddle point
y_min = floor(log10(min(c(ARE_f3, ARE_d3, ARE_s3, ARE_m3, ARE_i3)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real3)))
x_max = ceiling(max(-log10(p_real3)))

plot(-log10(p_real3), log10(ARE_s3), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real3), log10(ARE_s3), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real3), log10(ARE_m3), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real3), log10(ARE_m3), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real3), log10(ARE_d3), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real3), log10(ARE_d3), col = "purple", lwd = 2, lty = 4)
#ind_d3 = min(which(ARE_d3>0.999))
#points(-log10(p_real3)[ind_d3], log10(ARE_d3[ind_d3]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real3), log10(ARE_f3), col = "green", cex = 2, pch = 2)
lines(-log10(p_real3), log10(ARE_f3), col = "green", lwd = 2, lty = 4)
#ind_f3 = min(which(ARE_f3>0.999))
#points(-log10(p_real3)[ind_f3], log10(ARE_f3[ind_f3])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real3), log10(ARE_i3), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real3), log10(ARE_i3), col = "orange", lwd = 2, lty = 4)
#ind_i3 = min(which(ARE_i3>0.999))
#points(-log10(p_real3)[ind_i3], log10(ARE_i3[ind_i3]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real3), label = ceiling(-log10(p_real3)), 
     font=2,
     cex.axis = 1.15)

y_min = floor(log10(min(c(ARE_f3, ARE_d3, ARE_s3, ARE_m3, ARE_i3)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='C', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("m")*bold(" = 50")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)
################################################################################
#rank = 100
p_m4 = rowSums(p_HMC4)/100
ARE_m4 = abs(p_m4 - p_real4) / p_real4

#saddle point
y_min = floor(log10(min(c(ARE_f4, ARE_d4, ARE_s4, ARE_m4, ARE_i4)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real4)))
x_max = ceiling(max(-log10(p_real4)))

plot(-log10(p_real4), log10(ARE_s4), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real4), log10(ARE_s4), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real4), log10(ARE_m4), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real4), log10(ARE_m4), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real4), log10(ARE_d4), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real4), log10(ARE_d4), col = "purple", lwd = 2, lty = 4)
#ind_d4 = min(which(ARE_d4>0.999))
#points(-log10(p_real4)[ind_d4], log10(ARE_d4[ind_d4]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real4), log10(ARE_f4), col = "green", cex = 2, pch = 2)
lines(-log10(p_real4), log10(ARE_f4), col = "green", lwd = 2, lty = 4)
#ind_f4 = min(which(ARE_f4>0.999))
#points(-log10(p_real4)[ind_f4], log10(ARE_f4[ind_f4])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real4), log10(ARE_i4), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real4), log10(ARE_i4), col = "orange", lwd = 2, lty = 4)
#ind_i4 = min(which(ARE_i4>0.999))
#points(-log10(p_real4)[ind_i4], log10(ARE_i4[ind_i4]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real4), label = ceiling(-log10(p_real4)), 
     font=2,
     cex.axis = 1.15)

y_min = floor(log10(min(c(ARE_f4, ARE_d4, ARE_s4, ARE_m4, ARE_i4)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='D', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("m")*bold(" = 100")), side=3, line=1, font=2, cex=3)
################################################################################
#rank = 200
p_m5 = rowSums(p_HMC5)/100
ARE_m5 = abs(p_m5 - p_real5) / p_real5

#saddle point
y_min = floor(log10(min(c(ARE_f5, ARE_d5, ARE_s5, ARE_m5, ARE_i5)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real5)))
x_max = ceiling(max(-log10(p_real5)))

plot(-log10(p_real5), log10(ARE_s5), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real5), log10(ARE_s5), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real5), log10(ARE_m5), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real5), log10(ARE_m5), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real5), log10(ARE_d5), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real5), log10(ARE_d5), col = "purple", lwd = 2, lty = 4)
#ind_d5 = min(which(ARE_d5>0.999))
#points(-log10(p_real5)[ind_d5], log10(ARE_d5[ind_d5]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real5), log10(ARE_f5), col = "green", cex = 2, pch = 2)
lines(-log10(p_real5), log10(ARE_f5), col = "green", lwd = 2, lty = 4)
#ind_f5 = min(which(ARE_f5>0.999))
#points(-log10(p_real5)[ind_f5], log10(ARE_f5[ind_f5])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real5), log10(ARE_i5), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real5), log10(ARE_i5), col = "orange", lwd = 2, lty = 4)
#ind_i5 = min(which(ARE_i5>0.999))
#points(-log10(p_real5)[ind_i5], log10(ARE_i5[ind_i5]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real5), label = ceiling(-log10(p_real5)), 
     font=2,
     cex.axis = 1.15)

y_min = floor(log10(min(c(ARE_f5, ARE_d5, ARE_s5, ARE_m5, ARE_i5)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='E', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("m")*bold(" = 200")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)
mtext(text=expression(bold("-lg(true ")*bolditalic("p")*bold("-value)")), side=1, line=5, font=2, cex=2)
################################################################################
#rank = 250
p_m6 = rowSums(p_HMC6)/100
ARE_m6 = abs(p_m6 - p_real6) / p_real6

#saddle point
y_min = floor(log10(min(c(ARE_f6, ARE_d6, ARE_s6, ARE_m6, ARE_i6)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real6)))
x_max = ceiling(max(-log10(p_real6)))

plot(-log10(p_real6), log10(ARE_s6), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real6), log10(ARE_s6), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real6), log10(ARE_m6), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real6), log10(ARE_m6), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real6), log10(ARE_d6), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real6), log10(ARE_d6), col = "purple", lwd = 2, lty = 4)
#ind_d6 = min(which(ARE_d6>0.999))
#points(-log10(p_real6)[ind_d6], log10(ARE_d6[ind_d6]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real6), log10(ARE_f6), col = "green", cex = 2, pch = 2)
lines(-log10(p_real6), log10(ARE_f6), col = "green", lwd = 2, lty = 4)
#ind_f6 = min(which(ARE_f6>0.999))
#points(-log10(p_real6)[ind_f6], log10(ARE_f6[ind_f6])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real6), log10(ARE_i6), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real6), log10(ARE_i6), col = "orange", lwd = 2, lty = 4)
#ind_i6 = min(which(ARE_i6>0.999))
#points(-log10(p_real6)[ind_i6], log10(ARE_i6[ind_i6]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real6), label = ceiling(-log10(p_real6)), 
     font=2,
     cex.axis = 1.15)

y_min = floor(log10(min(c(ARE_f6, ARE_d6, ARE_s6, ARE_m6, ARE_i6)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

legend(x=-log10(p_real1)[18],y=-7, col = c("blue","black","purple", "green", "orange"), cex = 3, pch = c(16, 0, 1, 2, 5), lty = 4, lwd=3, 
       legend = c("MCMC-CE","Saddlepoint", "Davies","Farebrother","Imhof"), bty = "n")

mtext(text='F', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("m")*bold(" = 250")), side=3, line=1, font=2, cex=3)
mtext(text=expression(bold("-lg(true ")*bolditalic("p")*bold("-value)")), side=1, line=5, font=2, cex=2)
dev.off()

