library(bigQF)
library(svd)

data(sequence)

G<-sequence 

H<-tcrossprod(G) 

time5 = proc.time()
H<-tcrossprod(G) 
test5 = eigen(H, symmetric=TRUE,only.values=TRUE)$values
time_eigen5 = proc.time() - time5

time3 = proc.time()
test3 = eigen(H, symmetric=TRUE,only.values=TRUE)$values
time_eigen = proc.time() - time3

time1 = proc.time()
test1 = seigen(H,n=100,spd=TRUE,q=1) 
time_ssvd1 = proc.time() - time1

time2 = proc.time()
test2 = ssvd(H,n=100,q=1) 
time_ssvd2 = proc.time() - time2

time4 = proc.time()
test4 = trlan.eigen(H, n=100)
time_lan = proc.time() - time4

time1 = proc.time()
test1 = seigen(H,n=150,spd=TRUE,q=1) 
time_ssvd1 = proc.time() - time1

time2 = proc.time()
test2 = ssvd(H,n=150,q=1) 
time_ssvd2 = proc.time() - time2

time4 = proc.time()
test4 = trlan.eigen(H, n=150)
time_lan = proc.time() - time4

time1 = proc.time()
test1 = seigen(H,n=200,spd=TRUE,q=1) 
time_ssvd1 = proc.time() - time1

time2 = proc.time()
test2 = ssvd(H,n=200,q=1) 
time_ssvd2 = proc.time() - time2

time4 = proc.time()
test4 = trlan.eigen(H, n=200)
time_lan = proc.time() - time4