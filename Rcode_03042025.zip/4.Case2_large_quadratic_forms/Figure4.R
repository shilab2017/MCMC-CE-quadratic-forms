rm(list=ls())

setwd("D:\\Dissertation_Vy\\paper\\paper\\results\\Figure4")

##----------------------------------------------------------------------------
#------- CREATING EXCEL FILE with 7 sheets -----------------------------------
# for Q1
load("D:\\Dissertation_Vy\\Simulations_RESULTS\\MCMC-CE_eigenVal500_NEW.RData")

df1 <- as.data.frame(cbind(q, dav, liu, ARE_l, saddle, ARE_sad, p_HMC_hat3, ARE_m3))
df1 <- df1[-1,] # remove the 1st row
df1 <- df1[-38,]   # remove the last row

colnames(df1) <- c("q","p_Davies",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE_k150",	"ARE_MCMC-CE_k150")

write.csv(df1, file = 'Q1.csv') 

# for Q2
#rm(list=ls())
load("D:\\Dissertation_Vy\\Simulations_RESULTS\\MCMC-CE_eigenVal1000_NEW.RData")
df2 <- as.data.frame(cbind(q, dav, liu, ARE_l, saddle, ARE_sad, p_HMC_hat3, ARE_m3))
q0=c(28.5,30,40,42,50,55,60,65,70,75,80,90,95,110,130,140,150,160,170,180,190,200)*10^3
# which(q %in% q0)

colnames(df2) <- c("q","p_Davies",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE_k150",	"ARE_MCMC-CE_k150")
df2 <- df2[which(q %in% q0),]

write.csv(df2, file = 'Q2.csv') 

# for Q3
load("D:\\Dissertation_Vy\\Simulations_RESULTS\\MCMC-CE_eigenVal2000_NEW.RData")
df3 <- as.data.frame(cbind(q, dav, liu, ARE_l, saddle, ARE_sad, p_HMC_hat3, ARE_m3))
colnames(df3) <- c("q","p_Davies",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE_k150",	"ARE_MCMC-CE_k150")
write.csv(df3, file = 'Q3.csv') 

# for Q4
load("D:\\Dissertation_Vy\\Simulations_RESULTS\\MCMC-CE_eigenVal7000_NEW.RData")
df4 <- as.data.frame(cbind(q, dav, liu, ARE_l, saddle, ARE_sad, p_HMC_hat3, ARE_m3))
colnames(df4) <- c("q","p_Davies",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE_k150",	"ARE_MCMC-CE_k150")
df4<- df4[-2,]

write.csv(df4, file = 'Q4.csv') 

# for Q6
#rm(list=ls())

load("D:\\Dissertation_Vy\\high_dimension\\high_dimension\\Chen2019_examples\\LargeQuadraticForm-master\\data\\MCMC-CE_eigenVal20000_NEW_FINAL.RData")
df6 <- as.data.frame(cbind(q, dav, liu, ARE_l, saddle, ARE_sad, p_HMC_hat3, ARE_m3)) # .RData contains df5 with the last wrong datapoint, that's why i put it in this order
colnames(df6) <- c("q","p_Davies",	                                                 # need to do rm(list=ls()) before every simulation
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE_k150",	"ARE_MCMC-CE_k150")

write.csv(df6, file = 'Q6.csv') 

# for Q5
load("D:\\Dissertation_Vy\\high_dimension\\high_dimension\\Chen2019_examples\\LargeQuadraticForm-master\\data\\MCMC-CE_eigenVal9000_NEW_FINAL.RData")
df5 <- as.data.frame(cbind(q, dav, liu, ARE_l, saddle, ARE_sad, p_HMC_hat3, ARE_m3))
colnames(df5) <- c("q","p_Davies",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE_k150",	"ARE_MCMC-CE_k150")
write.csv(df5, file = 'Q5.csv') 


# for 10k rank Allelic Series data
df7 <- as.data.frame(read.csv("D:\\Dissertation_Vy\\Simulations_RESULTS\\last_sim2.csv"))
colnames(df7) <- c("q","p_Davies",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MS_100L",	"ARE_MS_100L",
                   "p_MS_100S",	"ARE_MS_100S",
                   "p_MS_150L",	"ARE_MS_150L",
                   "p_MS_150L",	"ARE_MS_150L")


library(openxlsx)

highdim_dataset_names <- list('Q1' = df1, 'Q2' = df2,'Q3' = df3, 'Q4' = df4, 'Q5' = df5,'Q6' = df6,'10k_rank_AllelicSeries' = df7)

#export each data frame to separate sheets in same Excel file
openxlsx::write.xlsx(highdim_dataset_names, file = 'highdim.xlsx') 

#___________ PLOTTING _______________________________________________________________

colnames(df1) <- c("q","p_D",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_Sad", 	"ARE_Sad",	
                   "p_M150",	"ARE_M150")
colnames(df2) <- c("q","p_D",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_Sad", 	"ARE_Sad",	
                   "p_M150",	"ARE_M150")

colnames(df3) <- c("q","p_D",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_Sad", 	"ARE_Sad",	
                   "p_M150",	"ARE_M150")
colnames(df4) <- c("q","p_D",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_Sad", 	"ARE_Sad",	
                   "p_M150",	"ARE_M150")
colnames(df5) <- c("q","p_D",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_Sad", 	"ARE_Sad",	
                   "p_M150",	"ARE_M150")
colnames(df6) <- c("q","p_D",	
                   "p_LTZ",	"ARE_LTZ",	
                   "p_Sad", 	"ARE_Sad",	
                   "p_M150",	"ARE_M150")

png("Figure4.png", width=17*3.3, height=22.5*3.3, units="cm", res=300)


margin=c(4,4,6,2)  # bottom, left, top, right
par(mfrow=c(3,2), omi=c(0.5,0.5,0,0), mar=margin)                      #set the size of the outer margins
#m = matrix(1:6, nrow=3,ncol=2, byrow = TRUE)
#layout(mat = m, heights = c(0.5,0.5))

# Q1 -----------------------------------------------

#p_m1 = df1$p_M150
#ARE_m1 = df1$ARE_M150

#saddle point
y_min = -5 #floor(log10(min(c(df1$ARE_LTZ, df1$ARE_M150, df1$ARE_Sad)))) #minimum of y axis
x_min = ceiling(min(-log10(df1$p_M150)))
x_max = ceiling(max(-log10(df1$p_M150)))

plot(-log10(df1$p_M150), log10(df1$ARE_Sad), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(df1$p_M150), log10(df1$ARE_Sad), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(df1$p_M150), log10(df1$ARE_M150), col = "blue", cex = 2, pch = 16)
lines(-log10(df1$p_M150), log10(df1$ARE_M150), col = "blue", lwd = 2, lty = 4)

#LTZ
points(-log10(df1$p_M150), log10(df1$ARE_LTZ), col = "purple", cex = 2, pch = 1)
lines(-log10(df1$p_M150), log10(df1$ARE_LTZ), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")



abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(df1$p_M150), label = ceiling(-log10(df1$p_M150)), 
     font=2,
     cex.axis = 1.43)

y_min = -5 #floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='A', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("Q1")*bold(", rank=305")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# Q2 -----------------------------------------------

#p_m1 = df1$p_M150
#ARE_m1 = df1$ARE_M150

#saddle point
y_min = -5 #floor(log10(min(c(df1$ARE_LTZ, df1$ARE_M150, df1$ARE_Sad)))) #minimum of y axis
x_min = ceiling(min(-log10(df2$p_M150)))
x_max = ceiling(max(-log10(df2$p_M150)))

plot(-log10(df2$p_M150), log10(df2$ARE_Sad), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(df2$p_M150), log10(df2$ARE_Sad), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(df2$p_M150), log10(df2$ARE_M150), col = "blue", cex = 2, pch = 16)
lines(-log10(df2$p_M150), log10(df2$ARE_M150), col = "blue", lwd = 2, lty = 4)

#LTZ
points(-log10(df2$p_M150), log10(df2$ARE_LTZ), col = "purple", cex = 2, pch = 1)
lines(-log10(df2$p_M150), log10(df2$ARE_LTZ), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")



abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(df2$p_M150), label = ceiling(-log10(df2$p_M150)), 
     font=2,
     cex.axis = 1.43)

y_min = -5 #floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='B', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("Q2")*bold(", rank=637")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)


# Q2 -----------------------------------------------

#p_m1 = df1$p_M150
#ARE_m1 = df1$ARE_M150

#saddle point
y_min = -5 #floor(log10(min(c(df1$ARE_LTZ, df1$ARE_M150, df1$ARE_Sad)))) #minimum of y axis
x_min = ceiling(min(-log10(df3$p_M150)))
x_max = ceiling(max(-log10(df3$p_M150)))

plot(-log10(df3$p_M150), log10(df3$ARE_Sad), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(df3$p_M150), log10(df3$ARE_Sad), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(df3$p_M150), log10(df3$ARE_M150), col = "blue", cex = 2, pch = 16)
lines(-log10(df3$p_M150), log10(df3$ARE_M150), col = "blue", lwd = 2, lty = 4)

#LTZ
points(-log10(df3$p_M150), log10(df3$ARE_LTZ), col = "purple", cex = 2, pch = 1)
lines(-log10(df3$p_M150), log10(df3$ARE_LTZ), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")



abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(df3$p_M150), label = ceiling(-log10(df3$p_M150)), 
     font=2,
     cex.axis = 1.43)

y_min = -5 #floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='C', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("Q3")*bold(", rank=1063")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# Q4 -----------------------------------------------

#p_m1 = df1$p_M150
#ARE_m1 = df1$ARE_M150

#saddle point
y_min = -5 #floor(log10(min(c(df1$ARE_LTZ, df1$ARE_M150, df1$ARE_Sad)))) #minimum of y axis
x_min = ceiling(min(-log10(df4$p_M150)))
x_max = ceiling(max(-log10(df4$p_M150)))

plot(-log10(df4$p_M150), log10(df4$ARE_Sad), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(df4$p_M150), log10(df4$ARE_Sad), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(df4$p_M150), log10(df4$ARE_M150), col = "blue", cex = 2, pch = 16)
lines(-log10(df4$p_M150), log10(df4$ARE_M150), col = "blue", lwd = 2, lty = 4)

#LTZ
points(-log10(df4$p_M150), log10(df4$ARE_LTZ), col = "purple", cex = 2, pch = 1)
lines(-log10(df4$p_M150), log10(df4$ARE_LTZ), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")



abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(df4$p_M150), label = ceiling(-log10(df4$p_M150)), 
     font=2,
     cex.axis = 1.43)

y_min = -5 #floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='D', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("Q4")*bold(", rank=3985")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)


# Q5 -----------------------------------------------

#p_m1 = df1$p_M150
#ARE_m1 = df1$ARE_M150

#saddle point
y_min = -5 #floor(log10(min(c(df1$ARE_LTZ, df1$ARE_M150, df1$ARE_Sad)))) #minimum of y axis
x_min = ceiling(min(-log10(df5$p_M150)))
x_max = ceiling(max(-log10(df5$p_M150)))

plot(-log10(df5$p_M150), log10(df5$ARE_Sad), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(df5$p_M150), log10(df5$ARE_Sad), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(df5$p_M150), log10(df5$ARE_M150), col = "blue", cex = 2, pch = 16)
lines(-log10(df5$p_M150), log10(df5$ARE_M150), col = "blue", lwd = 2, lty = 4)

#LTZ
points(-log10(df5$p_M150), log10(df5$ARE_LTZ), col = "purple", cex = 2, pch = 1)
lines(-log10(df5$p_M150), log10(df5$ARE_LTZ), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")



abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(df5$p_M150), label = ceiling(-log10(df5$p_M150)), 
     font=2,
     cex.axis = 1.43)

y_min = -5 #floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='E', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("Q5")*bold(", rank=4984")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)
mtext(text=expression(bold("-lg(")*bolditalic("p")*bold("-value)")), side=1, line=5, font=2, cex=2)


# Q6 -----------------------------------------------

#p_m1 = df1$p_M150
#ARE_m1 = df1$ARE_M150

#saddle point
y_min = -5 #floor(log10(min(c(df1$ARE_LTZ, df1$ARE_M150, df1$ARE_Sad)))) #minimum of y axis
x_min = ceiling(min(-log10(df6$p_M150)))
x_max = ceiling(max(-log10(df6$p_M150)))

plot(-log10(df6$p_M150), log10(df6$ARE_Sad), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(df6$p_M150), log10(df6$ARE_Sad), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(df6$p_M150), log10(df6$ARE_M150), col = "blue", cex = 2, pch = 16)
lines(-log10(df6$p_M150), log10(df6$ARE_M150), col = "blue", lwd = 2, lty = 4)

#LTZ
points(-log10(df6$p_M150), log10(df6$ARE_LTZ), col = "purple", cex = 2, pch = 1)
lines(-log10(df6$p_M150), log10(df6$ARE_LTZ), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")



abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(df6$p_M150), label = ceiling(-log10(df6$p_M150)), 
     font=2,
     cex.axis = 1.43)

y_min = -5 #floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='F', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("Q6")*bold(", rank=11259")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)
mtext(text=expression(bold("-lg(")*bolditalic("p")*bold("-value)")), side=1, line=5, font=2, cex=2)


legend(x=-log10(df6$p_M150)[13],y=-2, col = c("blue","black","purple"), cex = 3, pch = c(16, 0, 1, 2, 5), lty = 4, lwd=3, 
       legend = c("MCMC-CE (Lanczos,k-150)","Saddlepoint", "LTZ"), bty = "n")


dev.off()