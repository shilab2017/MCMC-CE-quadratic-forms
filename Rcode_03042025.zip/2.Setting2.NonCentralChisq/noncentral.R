rm(list=ls())

# LIBRARY 
library(MASS)         # To generate multivariate normal distribution
library(CompQuadForm) # For existing methods
library(survey)       # For saddle point method
library(doParallel)
library(doRNG)
library(tmg)          # For rtmg : HMC_Sampler

source('HMC_sampler.R')

# we can use the property of non-central chi-square variables mentioned in Jun Shao's slides
# So X^2 (10,10) = sum of 10 X^2 (1,1)

#--------------------------------------------------------------------------------------------------------------------
### Setting 1:  non-central chisq df =10, ncp = 10
# Set initial values

#q1=c(80,100,300,500,700,1000,1200,1500,1600,1700)
q1=c(50,80,100, 150,200,250,300,350,400,450,500,550,600,610,620) # prob limit at E-100

#q1= sort(sample.int(n = 700,size = 15))
p_real1 = pchisq(q=q1, df=10, ncp=10, lower.tail = F) # noncentral chisq (10,10)
p_real1

lambda1 = rep(1,10)
delta1 = rep(1,10)

h1 = rep(1,10)

D1 = diag(lambda1) 

p_d1 = p_f1 = p_i1 = p_l1 = p_s1 = NA
ARE_d1 = ARE_f1 = ARE_i1 = ARE_l1 = ARE_s1 = ARE_m1 = NA
time_d1 = time_f1 = time_i1 = time_l1 = time_s1 = matrix(0, nrow=length(q1), ncol=5)

n_sum = length(h1) 

# Set parameters for HMC-CE:
sigma1 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu1 = sqrt(delta1)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M1 = solve(sigma1)
r1 = as.vector(M1 %*% mu1)
initial1 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A1 = D1
B1 = rep(0,n_sum)
C1 = (-q1)

p_HMC1 = matrix(0, nrow=length(q1), ncol=100)
p_HMC_hat1 = ARE_HMC1 = SMSE_HMC1 = rep(NA, length(q1))
time.taken1 = list()

for(k in 1:length(q1)){
  
  #Davies method
  start_d = proc.time()
  p_d1[k] = davies(q1[k], lambda=lambda1, h=h1, delta = delta1, sigma=0)$Qq     
  time_d1[k,] = proc.time() - start_d
  ARE_d1[k] = abs(p_d1[k]-p_real1[k])/p_real1[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f1[k] = farebrother(q=q1[k], lambda=lambda1, h=h1, delta = delta1, eps=1e-150)$Qq 
  time_f1[k,] = proc.time() - start_f
  ARE_f1[k] = abs(p_f1[k]-p_real1[k])/p_real1[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i1[k] = imhof(q=q1[k], lambda=lambda1, h=h1, delta = delta1)$Qq 
  time_i1[k,] = proc.time() - start_i
  ARE_i1[k] = abs(p_i1[k]-p_real1[k])/p_real1[k]
  
  #Liu method
  start_l = proc.time()
  p_l1[k] = liu(q1[k], lambda=lambda1, h=h1, delta = delta1) 
  time_l1[k,] = proc.time() - start_l
  ARE_l1[k] = abs(p_l1[k]-p_real1[k])/p_real1[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s1[k] = pchisqsum(q1[k], lower.tail = FALSE, df = h1, a = lambda1, method = "sad")
  time_s1[k,] = proc.time() - start_s
  ARE_s1[k] = abs(p_s1[k]-p_real1[k])/p_real1[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr1 = list(list(A1,B1,C1[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M1, r=r1, constr=constr1, q=q1[k], initial=initial1, mu=mu1, sigma=sigma1, D=D1)
  p_HMC1[k,] = res[,1]
  time.taken1[[k]] = res[,2:6]
  ARE_m1[k] = abs(mean(p_HMC1[k,])-p_real1[k])/p_real1[k] # real p-values are known
}


p_d1
p_f1
p_i1
p_l1
p_s1

p_HMC_hat1 <- rowMeans(p_HMC1)
p_HMC_hat1



# ---- 04/12/2024-------------------------------------------------
Tab1 <- cbind(q1, p_real1,  p_d1, ARE_d1, time_d1[,3]
                , p_f1,  ARE_f1, time_f1[,3]
                , p_i1, ARE_i1, time_i1[,3]
                , p_l1, ARE_l1, time_l1[,3]
                , p_s1, ARE_s1, time_s1[,3]
                , p_HMC_hat1, ARE_m1)

colnames(Tab1) <- c("q","real_p-values",
                      "p_Davies",	"ARE_Davies",	"Time_Davies",	
                      "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                      "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                      "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                      "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                      "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab1,'noncentral_n10_ncp10.csv')


save.image(file="noncentral_n10_ncp10.RData") # ---- 04/12/2024----


#_______________________________________________________________________________

### Setting 2:  non-central chisq df =10, ncp = 25
# Set initial values

q2=c(50,100, 130,170,200,230,260,280,300,350,400,450,500,530,560,580,600,620,640,660,680,700) # prob limit at E-100

p_real2 = pchisq(q=q2, df=10, ncp=25, lower.tail = F) # noncentral chisq (10,25)
p_real2

lambda2 = rep(1,10)
delta2 = rep(2.5,10)

h2 = rep(1,10)

D2 = diag(lambda2) 

p_d2 = p_f2 = p_i2 = p_l2 = p_s2 = NA
ARE_d2 = ARE_f2 = ARE_i2 = ARE_l2 = ARE_s2 = ARE_m2 = NA
time_d2 = time_f2 = time_i2 = time_l2 = time_s2 = matrix(0, nrow=length(q2), ncol=5)

n_sum = length(h2) 

# Set parameters for HMC-CE:
sigma2 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu2 = sqrt(delta2)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M2 = solve(sigma2)
r2 = as.vector(M2 %*% mu2)
initial2 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A2 = D2
B2 = rep(0,n_sum)
C2 = (-q2)

p_HMC2 = matrix(0, nrow=length(q2), ncol=100)
p_HMC_hat2 = ARE_HMC2 = SMSE_HMC2 = rep(NA, length(q2))
time.taken2 = list()

for(k in 1:length(q2)){
  
  #Davies method
  start_d = proc.time()
  p_d2[k] = davies(q2[k], lambda=lambda2, h=h2, delta = delta2, sigma=0)$Qq     
  time_d2[k,] = proc.time() - start_d
  ARE_d2[k] = abs(p_d2[k]-p_real2[k])/p_real2[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f2[k] = farebrother(q=q2[k], lambda=lambda2, h=h2, delta = delta2, eps=1e-150)$Qq 
  time_f2[k,] = proc.time() - start_f
  ARE_f2[k] = abs(p_f2[k]-p_real2[k])/p_real2[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i2[k] = imhof(q=q2[k], lambda=lambda2, h=h2, delta = delta2)$Qq 
  time_i2[k,] = proc.time() - start_i
  ARE_i2[k] = abs(p_i2[k]-p_real2[k])/p_real2[k]
  
  #Liu method
  start_l = proc.time()
  p_l2[k] = liu(q2[k], lambda=lambda2, h=h2, delta = delta2) 
  time_l2[k,] = proc.time() - start_l
  ARE_l2[k] = abs(p_l2[k]-p_real2[k])/p_real2[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s2[k] = pchisqsum(q2[k], lower.tail = FALSE, df = h2, a = lambda2, method = "sad")
  time_s2[k,] = proc.time() - start_s
  ARE_s2[k] = abs(p_s2[k]-p_real2[k])/p_real2[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr2 = list(list(A2,B2,C2[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M2, r=r2, constr=constr2, q=q2[k], initial=initial2, mu=mu2, sigma=sigma2, D=D2)
  p_HMC2[k,] = res[,1]
  time.taken2[[k]] = res[,2:6]
  ARE_m2[k] = abs(mean(p_HMC2[k,])-p_real2[k])/p_real2[k] # real p-values are known
}


p_d2
p_f2
p_i2
p_l2
p_s2

p_HMC_hat2 <- rowMeans(p_HMC2)
p_HMC_hat2


Tab2 <- cbind(q2, p_real2,  p_d2, ARE_d2, time_d2[,3]
              , p_f2,  ARE_f2, time_f2[,3]
              , p_i2, ARE_i2, time_i2[,3]
              , p_l2, ARE_l2, time_l2[,3]
              , p_s2, ARE_s2, time_s2[,3]
              , p_HMC_hat2, ARE_m2)

colnames(Tab2) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab2,'noncentral_n10_ncp25.csv')


save.image(file="noncentral_n10_ncp25.RData") # ---- 04/13/2024----

#_______________________________________________________________________________

### Setting 3:  non-central chisq df =10, ncp = 50
# Set initial values

q3=c(100,150,180,200,220,240,260,280,300,320,340,360,380,400,420,440,460,480,500,520,540,560,580,600,610,620,640,680,700,720,740,760,780,800) # prob limit at E-100

p_real3 = pchisq(q=q3, df=10, ncp=50, lower.tail = F) # noncentral chisq (10,25)
p_real3

lambda3 = rep(1,10)
delta3 = rep(5,10)

h3 = rep(1,10)

D3 = diag(lambda3) 

p_d3 = p_f3 = p_i3 = p_l3 = p_s3 = NA
ARE_d3 = ARE_f3 = ARE_i3 = ARE_l3 = ARE_s3 = ARE_m3 = NA
time_d3 = time_f3 = time_i3 = time_l3 = time_s3 = matrix(0, nrow=length(q3), ncol=5)

n_sum = length(h3) 

# Set parameters for HMC-CE:
sigma3 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu3 = sqrt(delta3)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M3 = solve(sigma3)
r3 = as.vector(M3 %*% mu3)
initial3 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A3 = D3
B3 = rep(0,n_sum)
C3 = (-q3)

p_HMC3 = matrix(0, nrow=length(q3), ncol=100)
p_HMC_hat3 = ARE_HMC3 = SMSE_HMC3 = rep(NA, length(q3))
time.taken3 = list()

for(k in 1:length(q3)){
  
  #Davies method
  start_d = proc.time()
  p_d3[k] = davies(q3[k], lambda=lambda3, h=h3, delta = delta3, sigma=0)$Qq     
  time_d3[k,] = proc.time() - start_d
  ARE_d3[k] = abs(p_d3[k]-p_real3[k])/p_real3[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f3[k] = farebrother(q=q3[k], lambda=lambda3, h=h3, delta = delta3, eps=1e-150)$Qq 
  time_f3[k,] = proc.time() - start_f
  ARE_f3[k] = abs(p_f3[k]-p_real3[k])/p_real3[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i3[k] = imhof(q=q3[k], lambda=lambda3, h=h3, delta = delta3)$Qq 
  time_i3[k,] = proc.time() - start_i
  ARE_i3[k] = abs(p_i3[k]-p_real3[k])/p_real3[k]
  
  #Liu method
  start_l = proc.time()
  p_l3[k] = liu(q3[k], lambda=lambda3, h=h3, delta = delta3) 
  time_l3[k,] = proc.time() - start_l
  ARE_l3[k] = abs(p_l3[k]-p_real3[k])/p_real3[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s3[k] = pchisqsum(q3[k], lower.tail = FALSE, df = h3, a = lambda3, method = "sad")
  time_s3[k,] = proc.time() - start_s
  ARE_s3[k] = abs(p_s3[k]-p_real3[k])/p_real3[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr3 = list(list(A3,B3,C3[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M3, r=r3, constr=constr3, q=q3[k], initial=initial3, mu=mu3, sigma=sigma3, D=D3)
  p_HMC3[k,] = res[,1]
  time.taken3[[k]] = res[,2:6]
  ARE_m3[k] = abs(mean(p_HMC3[k,])-p_real3[k])/p_real3[k] # real p-values are known
}


p_d3
p_f3
p_i3
p_l3
p_s3

p_HMC_hat3 <- rowMeans(p_HMC3)
p_HMC_hat3


Tab3 <- cbind(q3, p_real3,  p_d3, ARE_d3, time_d3[,3]
              , p_f3,  ARE_f3, time_f3[,3]
              , p_i3, ARE_i3, time_i3[,3]
              , p_l3, ARE_l3, time_l3[,3]
              , p_s3, ARE_s3, time_s3[,3]
              , p_HMC_hat3, ARE_m3)

colnames(Tab3) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab3,'noncentral_n10_ncp50.csv')


save.image(file="noncentral_n10_ncp50.RData") # ---- 04/13/2024----

#_______________________________________________________________________________
### Setting 4:  non-central chisq df =50, ncp = 10
# Set initial values

q4=c(100,120,140,160,180,200,220,240,260,280,300,320,340,360,380,400,420,440,460,480,500,520,540,560,580,600,620,640,660,680,700,705,710) # prob limit at E-100

p_real4 = pchisq(q=q4, df=50, ncp=10, lower.tail = F) # noncentral chisq (10,10)
p_real4

lambda4 = rep(1,50)
delta4 = rep(1/5,50)

h4 = rep(1,50)

D4 = diag(lambda4) 

p_d4 = p_f4 = p_i4 = p_l4 = p_s4 = NA
ARE_d4 = ARE_f4 = ARE_i4 = ARE_l4 = ARE_s4 = ARE_m4 = NA
time_d4 = time_f4 = time_i4 = time_l4 = time_s4 = matrix(0, nrow=length(q4), ncol=5)

n_sum = length(h4) 

# Set parameters for HMC-CE:
sigma4 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu4 = sqrt(delta4)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M4 = solve(sigma4)
r4 = as.vector(M4 %*% mu4)
initial4 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A4 = D4
B4 = rep(0,n_sum)
C4 = (-q4)

p_HMC4 = matrix(0, nrow=length(q4), ncol=100)
p_HMC_hat4 = ARE_HMC4 = SMSE_HMC4 = rep(NA, length(q4))
time.taken4 = list()

for(k in 1:length(q4)){
  
  #Davies method
  start_d = proc.time()
  p_d4[k] = davies(q4[k], lambda=lambda4, h=h4, delta = delta4, sigma=0)$Qq     
  time_d4[k,] = proc.time() - start_d
  ARE_d4[k] = abs(p_d4[k]-p_real4[k])/p_real4[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f4[k] = farebrother(q=q4[k], lambda=lambda4, h=h4, delta = delta4, eps=1e-150)$Qq 
  time_f4[k,] = proc.time() - start_f
  ARE_f4[k] = abs(p_f4[k]-p_real4[k])/p_real4[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i4[k] = imhof(q=q4[k], lambda=lambda4, h=h4, delta = delta4)$Qq 
  time_i4[k,] = proc.time() - start_i
  ARE_i4[k] = abs(p_i4[k]-p_real4[k])/p_real4[k]
  
  #Liu method
  start_l = proc.time()
  p_l4[k] = liu(q4[k], lambda=lambda4, h=h4, delta = delta4) 
  time_l4[k,] = proc.time() - start_l
  ARE_l4[k] = abs(p_l4[k]-p_real4[k])/p_real4[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s4[k] = pchisqsum(q4[k], lower.tail = FALSE, df = h4, a = lambda4, method = "sad")
  time_s4[k,] = proc.time() - start_s
  ARE_s4[k] = abs(p_s4[k]-p_real4[k])/p_real4[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr4 = list(list(A4,B4,C4[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M4, r=r4, constr=constr4, q=q4[k], initial=initial4, mu=mu4, sigma=sigma4, D=D4)
  p_HMC4[k,] = res[,1]
  time.taken4[[k]] = res[,2:6]
  ARE_m4[k] = abs(mean(p_HMC4[k,])-p_real4[k])/p_real4[k] # real p-values are known
}


p_d4
p_f4
p_i4
p_l4
p_s4

p_HMC_hat4 <- rowMeans(p_HMC4)
p_HMC_hat4



# ---- 04/13/2024-------------------------------------------------
Tab4 <- cbind(q4, p_real4,  p_d4, ARE_d4, time_d4[,3]
              , p_f4,  ARE_f4, time_f4[,3]
              , p_i4, ARE_i4, time_i4[,3]
              , p_l4, ARE_l4, time_l4[,3]
              , p_s4, ARE_s4, time_s4[,3]
              , p_HMC_hat4, ARE_m4)

colnames(Tab4) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab4,'noncentral_n50_ncp10.csv')

save.image(file="noncentral_n50_ncp10.RData") # ---- 04/13/2024----


#_______________________________________________________________________________

### Setting 5:  non-central chisq df =50, ncp = 25
# Set initial values

q5=c(100, 130,170,200,230,260,280,300,330,360,400,425,450,475,500,525,550,565,580,600,620,640,660,680,700,720,740,760,780,800) # prob limit at E-100

p_real5 = pchisq(q=q5, df=50, ncp=25, lower.tail = F) # noncentral chisq (10,25)
p_real5

lambda5 = rep(1,50)
delta5 = rep(1/2,50)

h5 = rep(1,50)

D5 = diag(lambda5) 

p_d5 = p_f5 = p_i5 = p_l5 = p_s5 = NA
ARE_d5 = ARE_f5 = ARE_i5 = ARE_l5 = ARE_s5 = ARE_m5 = NA
time_d5 = time_f5 = time_i5 = time_l5 = time_s5 = matrix(0, nrow=length(q5), ncol=5)

n_sum = length(h5) 

# Set parameters for HMC-CE:
sigma5 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu5 = sqrt(delta5)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M5 = solve(sigma5)
r5 = as.vector(M5 %*% mu5)
initial5 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A5 = D5
B5 = rep(0,n_sum)
C5 = (-q5)

p_HMC5 = matrix(0, nrow=length(q5), ncol=100)
p_HMC_hat5 = ARE_HMC5 = SMSE_HMC5 = rep(NA, length(q5))
time.taken5 = list()

for(k in 1:length(q5)){
  
  #Davies method
  start_d = proc.time()
  p_d5[k] = davies(q5[k], lambda=lambda5, h=h5, delta = delta5, sigma=0)$Qq     
  time_d5[k,] = proc.time() - start_d
  ARE_d5[k] = abs(p_d5[k]-p_real5[k])/p_real5[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f5[k] = farebrother(q=q5[k], lambda=lambda5, h=h5, delta = delta5, eps=1e-150)$Qq 
  time_f5[k,] = proc.time() - start_f
  ARE_f5[k] = abs(p_f5[k]-p_real5[k])/p_real5[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i5[k] = imhof(q=q5[k], lambda=lambda5, h=h5, delta = delta5)$Qq 
  time_i5[k,] = proc.time() - start_i
  ARE_i5[k] = abs(p_i5[k]-p_real5[k])/p_real5[k]
  
  #Liu method
  start_l = proc.time()
  p_l5[k] = liu(q5[k], lambda=lambda5, h=h5, delta = delta5) 
  time_l5[k,] = proc.time() - start_l
  ARE_l5[k] = abs(p_l5[k]-p_real5[k])/p_real5[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s5[k] = pchisqsum(q5[k], lower.tail = FALSE, df = h5, a = lambda5, method = "sad")
  time_s5[k,] = proc.time() - start_s
  ARE_s5[k] = abs(p_s5[k]-p_real5[k])/p_real5[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr5 = list(list(A5,B5,C5[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M5, r=r5, constr=constr5, q=q5[k], initial=initial5, mu=mu5, sigma=sigma5, D=D5)
  p_HMC5[k,] = res[,1]
  time.taken5[[k]] = res[,2:6]
  ARE_m5[k] = abs(mean(p_HMC5[k,])-p_real5[k])/p_real5[k] # real p-values are known
}


p_d5
p_f5
p_i5
p_l5
p_s5

p_HMC_hat5 <- rowMeans(p_HMC5)
p_HMC_hat5


Tab5 <- cbind(q5, p_real5,  p_d5, ARE_d5, time_d5[,3]
              , p_f5,  ARE_f5, time_f5[,3]
              , p_i5, ARE_i5, time_i5[,3]
              , p_l5, ARE_l5, time_l5[,3]
              , p_s5, ARE_s5, time_s5[,3]
              , p_HMC_hat5, ARE_m5)

colnames(Tab5) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab5,'noncentral_n50_ncp25.csv')


save.image(file="noncentral_n50_ncp25.RData") # ---- 04/13/2024----

#_______________________________________________________________________________

### Setting 6:  non-central chisq df =50, ncp = 50
# Set initial values

q6=c(170,200,220,240,260,280,300,320,340,360,380,400,420,440,460,480,500,520,540,560,580,600,620,640,680,700,720,740,760,780,800,820,835,850,860,870,880) # prob limit at E-100

p_real6 = pchisq(q=q6, df=50, ncp=50, lower.tail = F) # noncentral chisq (10,25)
p_real6

lambda6 = rep(1,50)
delta6 = rep(1,50)

h6 = rep(1,50)

D6 = diag(lambda6) 

p_d6 = p_f6 = p_i6 = p_l6 = p_s6 = NA
ARE_d6 = ARE_f6 = ARE_i6 = ARE_l6 = ARE_s6 = ARE_m6 = NA
time_d6 = time_f6 = time_i6 = time_l6 = time_s6 = matrix(0, nrow=length(q6), ncol=5)

n_sum = length(h6) 

# Set parameters for HMC-CE:
sigma6 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu6 = sqrt(delta6)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M6 = solve(sigma6)
r6 = as.vector(M6 %*% mu6)
initial6 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A6 = D6
B6 = rep(0,n_sum)
C6 = (-q6)

p_HMC6 = matrix(0, nrow=length(q6), ncol=100)
p_HMC_hat6 = ARE_HMC6 = SMSE_HMC6 = rep(NA, length(q6))
time.taken6 = list()

for(k in 1:length(q6)){
  
  #Davies method
  start_d = proc.time()
  p_d6[k] = davies(q6[k], lambda=lambda6, h=h6, delta = delta6, sigma=0)$Qq     
  time_d6[k,] = proc.time() - start_d
  ARE_d6[k] = abs(p_d6[k]-p_real6[k])/p_real6[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f6[k] = farebrother(q=q6[k], lambda=lambda6, h=h6, delta = delta6, eps=1e-150)$Qq 
  time_f6[k,] = proc.time() - start_f
  ARE_f6[k] = abs(p_f6[k]-p_real6[k])/p_real6[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i6[k] = imhof(q=q6[k], lambda=lambda6, h=h6, delta = delta6)$Qq 
  time_i6[k,] = proc.time() - start_i
  ARE_i6[k] = abs(p_i6[k]-p_real6[k])/p_real6[k]
  
  #Liu method
  start_l = proc.time()
  p_l6[k] = liu(q6[k], lambda=lambda6, h=h6, delta = delta6) 
  time_l6[k,] = proc.time() - start_l
  ARE_l6[k] = abs(p_l6[k]-p_real6[k])/p_real6[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s6[k] = pchisqsum(q6[k], lower.tail = FALSE, df = h6, a = lambda6, method = "sad")
  time_s6[k,] = proc.time() - start_s
  ARE_s6[k] = abs(p_s6[k]-p_real6[k])/p_real6[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr6 = list(list(A6,B6,C6[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M6, r=r6, constr=constr6, q=q6[k], initial=initial6, mu=mu6, sigma=sigma6, D=D6)
  p_HMC6[k,] = res[,1]
  time.taken6[[k]] = res[,2:6]
  ARE_m6[k] = abs(mean(p_HMC6[k,])-p_real6[k])/p_real6[k] # real p-values are known
}


p_d6
p_f6
p_i6
p_l6
p_s6

p_HMC_hat6 <- rowMeans(p_HMC6)
p_HMC_hat6


Tab6 <- cbind(q6, p_real6,  p_d6, ARE_d6, time_d6[,3]
              , p_f6,  ARE_f6, time_f6[,3]
              , p_i6, ARE_i6, time_i6[,3]
              , p_l6, ARE_l6, time_l6[,3]
              , p_s6, ARE_s6, time_s6[,3]
              , p_HMC_hat6, ARE_m6)

colnames(Tab6) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab6,'noncentral_n50_ncp50.csv')


save.image(file="noncentral_n50_ncp50.RData") # ---- 04/13/2024----

#_______________________________________________________________________________
### Setting 7:  non-central chisq df =100, ncp = 10
# Set initial values

#q7=c(80,100,300,500,700,1000,1200,1500,1600,1700)
q7=c(160,180,200,220,240,260,280,300,320,340,360,380,400,420,435,450,470,485,500,525,550,575,600,625,650,675,700,715,730,740,750,765,780,800,810) # prob limit at E-100

#q1= sort(sample.int(n = 700,size = 15))
p_real7 = pchisq(q=q7, df=100, ncp=10, lower.tail = F) # noncentral chisq (10,10)
p_real7

lambda7 = rep(1,100)
delta7 = rep(1/10,100)

h7 = rep(1,100)

D7 = diag(lambda7) 

p_d7 = p_f7 = p_i7 = p_l7 = p_s7 = NA
ARE_d7 = ARE_f7 = ARE_i7 = ARE_l7 = ARE_s7 = ARE_m7 = NA
time_d7 = time_f7 = time_i7 = time_l7 = time_s7 = matrix(0, nrow=length(q7), ncol=5)

n_sum = length(h7) 

# Set parameters for HMC-CE:
sigma7 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu7 = sqrt(delta7)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M7 = solve(sigma7)
r7 = as.vector(M7 %*% mu7)
initial7 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A7 = D7
B7 = rep(0,n_sum)
C7 = (-q7)

p_HMC7 = matrix(0, nrow=length(q7), ncol=100)
p_HMC_hat7 = ARE_HMC7 = SMSE_HMC7 = rep(NA, length(q7))
time.taken7 = list()

for(k in 1:length(q7)){
  
  #Davies method
  start_d = proc.time()
  p_d7[k] = davies(q7[k], lambda=lambda7, h=h7, delta = delta7, sigma=0)$Qq     
  time_d7[k,] = proc.time() - start_d
  ARE_d7[k] = abs(p_d7[k]-p_real7[k])/p_real7[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f7[k] = farebrother(q=q7[k], lambda=lambda7, h=h7, delta = delta7, eps=1e-150)$Qq 
  time_f7[k,] = proc.time() - start_f
  ARE_f7[k] = abs(p_f7[k]-p_real7[k])/p_real7[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i7[k] = imhof(q=q7[k], lambda=lambda7, h=h7, delta = delta7)$Qq 
  time_i7[k,] = proc.time() - start_i
  ARE_i7[k] = abs(p_i7[k]-p_real7[k])/p_real7[k]
  
  #Liu method
  start_l = proc.time()
  p_l7[k] = liu(q7[k], lambda=lambda7, h=h7, delta = delta7) 
  time_l7[k,] = proc.time() - start_l
  ARE_l7[k] = abs(p_l7[k]-p_real7[k])/p_real7[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s7[k] = pchisqsum(q7[k], lower.tail = FALSE, df = h7, a = lambda7, method = "sad")
  time_s7[k,] = proc.time() - start_s
  ARE_s7[k] = abs(p_s7[k]-p_real7[k])/p_real7[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr7 = list(list(A7,B7,C7[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M7, r=r7, constr=constr7, q=q7[k], initial=initial7, mu=mu7, sigma=sigma7, D=D7)
  p_HMC7[k,] = res[,1]
  time.taken7[[k]] = res[,2:6]
  ARE_m7[k] = abs(mean(p_HMC7[k,])-p_real7[k])/p_real7[k] # real p-values are known
}


p_d7
p_f7
p_i7
p_l7
p_s7

p_HMC_hat7 <- rowMeans(p_HMC7)
p_HMC_hat7



# ---- 04/13/2024-------------------------------------------------
Tab7 <- cbind(q7, p_real7,  p_d7, ARE_d7, time_d7[,3]
              , p_f7,  ARE_f7, time_f7[,3]
              , p_i7, ARE_i7, time_i7[,3]
              , p_l7, ARE_l7, time_l7[,3]
              , p_s7, ARE_s7, time_s7[,3]
              , p_HMC_hat7, ARE_m7)

colnames(Tab7) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab7,'noncentral_n100_ncp10.csv')


save.image(file="noncentral_n100_ncp10.RData") # ---- 04/13/2024----


#_______________________________________________________________________________

### Setting 8:  non-central chisq df =100, ncp = 25
# Set initial values

q8=c(200,250,300,320,340,360,380,400,425,450,475,500,525,550,575,600,625,650,675,700,720,735,750,765,780,800,810,850,900) # prob limit at E-100

p_real8 = pchisq(q=q8, df=100, ncp=25, lower.tail = F) # noncentral chisq (10,25)
p_real8

lambda8 = rep(1,100)
delta8 = rep(2.5/10,100)

h8 = rep(1,100)

D8 = diag(lambda8) 

p_d8 = p_f8 = p_i8 = p_l8 = p_s8 = NA
ARE_d8 = ARE_f8 = ARE_i8 = ARE_l8 = ARE_s8 = ARE_m8 = NA
time_d8 = time_f8 = time_i8 = time_l8 = time_s8 = matrix(0, nrow=length(q8), ncol=5)

n_sum = length(h8) 

# Set parameters for HMC-CE:
sigma8 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu8 = sqrt(delta8)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M8 = solve(sigma8)
r8 = as.vector(M8 %*% mu8)
initial8 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A8 = D8
B8 = rep(0,n_sum)
C8 = (-q8)

p_HMC8 = matrix(0, nrow=length(q8), ncol=100)
p_HMC_hat8 = ARE_HMC8 = SMSE_HMC8 = rep(NA, length(q8))
time.taken8 = list()

for(k in 1:length(q8)){
  
  #Davies method
  start_d = proc.time()
  p_d8[k] = davies(q8[k], lambda=lambda8, h=h8, delta = delta8, sigma=0)$Qq     
  time_d8[k,] = proc.time() - start_d
  ARE_d8[k] = abs(p_d8[k]-p_real8[k])/p_real8[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f8[k] = farebrother(q=q8[k], lambda=lambda8, h=h8, delta = delta8, eps=1e-150)$Qq 
  time_f8[k,] = proc.time() - start_f
  ARE_f8[k] = abs(p_f8[k]-p_real8[k])/p_real8[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i8[k] = imhof(q=q8[k], lambda=lambda8, h=h8, delta = delta8)$Qq 
  time_i8[k,] = proc.time() - start_i
  ARE_i8[k] = abs(p_i8[k]-p_real8[k])/p_real8[k]
  
  #Liu method
  start_l = proc.time()
  p_l8[k] = liu(q8[k], lambda=lambda8, h=h8, delta = delta8) 
  time_l8[k,] = proc.time() - start_l
  ARE_l8[k] = abs(p_l8[k]-p_real8[k])/p_real8[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s8[k] = pchisqsum(q8[k], lower.tail = FALSE, df = h8, a = lambda8, method = "sad")
  time_s8[k,] = proc.time() - start_s
  ARE_s8[k] = abs(p_s8[k]-p_real8[k])/p_real8[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr8 = list(list(A8,B8,C8[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M8, r=r8, constr=constr8, q=q8[k], initial=initial8, mu=mu8, sigma=sigma8, D=D8)
  p_HMC8[k,] = res[,1]
  time.taken8[[k]] = res[,2:6]
  ARE_m8[k] = abs(mean(p_HMC8[k,])-p_real8[k])/p_real8[k] # real p-values are known
}


p_d8
p_f8
p_i8
p_l8
p_s8

p_HMC_hat8 <- rowMeans(p_HMC8)
p_HMC_hat8


Tab8 <- cbind(q8, p_real8,  p_d8, ARE_d8, time_d8[,3]
              , p_f8,  ARE_f8, time_f8[,3]
              , p_i8, ARE_i8, time_i8[,3]
              , p_l8, ARE_l8, time_l8[,3]
              , p_s8, ARE_s8, time_s8[,3]
              , p_HMC_hat8, ARE_m8)

colnames(Tab8) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab8,'noncentral_n100_ncp25.csv')


save.image(file="noncentral_n100_ncp25.RData") # ---- 04/13/2024----

#_______________________________________________________________________________

### Setting 9:  non-central chisq df =100, ncp = 50
# Set initial values

q9=c(225,250,275,300,320,340,360,380,400,425,450,475,500,525,550,575,600,625,650,675,700,725,750,775,800,810,850,875,900,925,950,975) # prob limit at E-100

p_real9 = pchisq(q=q9, df=100, ncp=50, lower.tail = F) # noncentral chisq (10,25)
p_real9

lambda9 = rep(1,100)
delta9 = rep(.5,100)

h9 = rep(1,100)

D9 = diag(lambda9) 

p_d9 = p_f9 = p_i9 = p_l9 = p_s9 = NA
ARE_d9 = ARE_f9 = ARE_i9 = ARE_l9 = ARE_s9 = ARE_m9 = NA
time_d9 = time_f9 = time_i9 = time_l9 = time_s9 = matrix(0, nrow=length(q9), ncol=5)

n_sum = length(h9) 

# Set parameters for HMC-CE:
sigma9 = diag(rep(1, n_sum)) # Covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu9 = sqrt(delta9)           # Mean of Y(multivariate normal), which is sqrt(delta)

# Alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M9 = solve(sigma9)
r9 = as.vector(M9 %*% mu9)
initial9 = rep(50, n_sum)    # Start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A9 = D9
B9 = rep(0,n_sum)
C9 = (-q9)

p_HMC9 = matrix(0, nrow=length(q9), ncol=100)
p_HMC_hat9 = ARE_HMC9 = SMSE_HMC9 = rep(NA, length(q9))
time.taken9 = list()

for(k in 1:length(q9)){
  
  #Davies method
  start_d = proc.time()
  p_d9[k] = davies(q9[k], lambda=lambda9, h=h9, delta = delta9, sigma=0)$Qq     
  time_d9[k,] = proc.time() - start_d
  ARE_d9[k] = abs(p_d9[k]-p_real9[k])/p_real9[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f9[k] = farebrother(q=q9[k], lambda=lambda9, h=h9, delta = delta9, eps=1e-150)$Qq 
  time_f9[k,] = proc.time() - start_f
  ARE_f9[k] = abs(p_f9[k]-p_real9[k])/p_real9[k]
  
  #Imhof method: doesn't work very well, can be skipped 
  start_i = proc.time()
  p_i9[k] = imhof(q=q9[k], lambda=lambda9, h=h9, delta = delta9)$Qq 
  time_i9[k,] = proc.time() - start_i
  ARE_i9[k] = abs(p_i9[k]-p_real9[k])/p_real9[k]
  
  #Liu method
  start_l = proc.time()
  p_l9[k] = liu(q9[k], lambda=lambda9, h=h9, delta = delta9) 
  time_l9[k,] = proc.time() - start_l
  ARE_l9[k] = abs(p_l9[k]-p_real9[k])/p_real9[k]
  
  #Saddle point method
  start_s = proc.time()
  p_s9[k] = pchisqsum(q9[k], lower.tail = FALSE, df = h9, a = lambda9, method = "sad")
  time_s9[k,] = proc.time() - start_s
  ARE_s9[k] = abs(p_s9[k]-p_real9[k])/p_real9[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate Gaussian
  constr9 = list(list(A9,B9,C9[k]))
  
  set.seed(2022)
  res = HMC_sampler(M=M9, r=r9, constr=constr9, q=q9[k], initial=initial9, mu=mu9, sigma=sigma9, D=D9)
  p_HMC9[k,] = res[,1]
  time.taken9[[k]] = res[,2:6]
  ARE_m9[k] = abs(mean(p_HMC9[k,])-p_real9[k])/p_real9[k] # real p-values are known
}


p_d9
p_f9
p_i9
p_l9
p_s9

p_HMC_hat9 <- rowMeans(p_HMC9)
p_HMC_hat9


Tab9 <- cbind(q9, p_real9,  p_d9, ARE_d9, time_d9[,3]
              , p_f9,  ARE_f9, time_f9[,3]
              , p_i9, ARE_i9, time_i9[,3]
              , p_l9, ARE_l9, time_l9[,3]
              , p_s9, ARE_s9, time_s9[,3]
              , p_HMC_hat9, ARE_m9)

colnames(Tab9) <- c("q","real_p-values",
                    "p_Davies",	"ARE_Davies",	"Time_Davies",	
                    "p_Farebrother", "ARE_Farebrother", "Time_Farebrother",	
                    "p_Imhof",	"ARE_Imhof",	"Time_Imhof", 
                    "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	"Time_Liu-Tang-Zhang", 
                    "p_saddlepoint", 	"ARE_saddlepoint",	"Time_saddlepoint",
                    "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(Tab9,'noncentral_n100_ncp50.csv')


save.image(file="noncentral_n100_ncp50.RData") # ---- 04/13/2024----

save.image(file="noncentral.RData") # ---- 04/14/2024----

#================================================================================
# ---- create excel file with multiple sheets ----------------------------------------------

df1 <- as.data.frame(cbind(q1, p_real1,  p_d1, ARE_d1, p_f1,  ARE_f1, p_i1, ARE_i1, p_l1, ARE_l1, p_s1, ARE_s1 
                           , p_HMC_hat1, ARE_m1)) 
colnames(df1) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df1, file = 'nonCentral_n10_ncp10.csv') 


df2 <- as.data.frame(cbind(q2, p_real2,  p_d2, ARE_d2, p_f2,  ARE_f2, p_i2, ARE_i2, p_l2, ARE_l2, p_s2, ARE_s2 
                           , p_HMC_hat2, ARE_m2)) 
colnames(df2) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df2, file = 'nonCentral_n10_ncp25.csv') 

df3 <- as.data.frame(cbind(q3, p_real3,  p_d3, ARE_d3, p_f3,  ARE_f3, p_i3, ARE_i3, p_l3, ARE_l3, p_s3, ARE_s3 
                           , p_HMC_hat3, ARE_m3)) 
colnames(df3) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df3, file = 'nonCentral_n10_ncp50.csv') 

df4 <- as.data.frame(cbind(q4, p_real4,  p_d4, ARE_d4, p_f4,  ARE_f4, p_i4, ARE_i4, p_l4, ARE_l4, p_s4, ARE_s4 
                           , p_HMC_hat4, ARE_m4)) 
colnames(df4) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df4, file = 'nonCentral_n50_ncp10.csv') 

df5 <- as.data.frame(cbind(q5, p_real5,  p_d5, ARE_d5, p_f5,  ARE_f5, p_i5, ARE_i5, p_l5, ARE_l5, p_s5, ARE_s5 
                           , p_HMC_hat5, ARE_m5)) 
colnames(df5) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df5, file = 'nonCentral_n50_ncp25.csv') 

df6 <- as.data.frame(cbind(q6, p_real6,  p_d6, ARE_d6, p_f6,  ARE_f6, p_i6, ARE_i6, p_l6, ARE_l6, p_s6, ARE_s6 
                           , p_HMC_hat6, ARE_m6)) 
colnames(df6) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df6, file = 'nonCentral_n50_ncp50.csv') 

df7 <- as.data.frame(cbind(q7, p_real7,  p_d7, ARE_d7, p_f7,  ARE_f7, p_i7, ARE_i7, p_l7, ARE_l7, p_s7, ARE_s7 
                           , p_HMC_hat7, ARE_m7)) 
colnames(df7) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df7, file = 'nonCentral_n100_ncp10.csv') 

df8 <- as.data.frame(cbind(q8, p_real8,  p_d8, ARE_d8, p_f8,  ARE_f8, p_i8, ARE_i8, p_l8, ARE_l8, p_s8, ARE_s8 
                           , p_HMC_hat8, ARE_m8)) 
colnames(df8) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df8, file = 'nonCentral_n100_ncp25.csv') 

df9 <- as.data.frame(cbind(q9, p_real9,  p_d9, ARE_d9, p_f9,  ARE_f9, p_i9, ARE_i9, p_l9, ARE_l9, p_s9, ARE_s9 
                           , p_HMC_hat9, ARE_m9)) 
colnames(df9) <- c("q","real_p-values",
                   "p_Davies",	"ARE_Davies",		
                   "p_Farebrother", "ARE_Farebrother", 	
                   "p_Imhof",	"ARE_Imhof",	
                   "p_Liu-Tang-Zhang",	"ARE_Liu-Tang-Zhang",	
                   "p_saddlepoint", 	"ARE_saddlepoint",	
                   "p_MCMC-CE",	"ARE_MCMC-CE")

write.csv(df9, file = 'nonCentral_n100_ncp50.csv') 

library(openxlsx)

ncp_dataset_names <- list('n10_ncp10' = df1, 'n10_ncp25' = df2, 'n10_ncp50' = df3, 'n50_ncp10' = df4, 'n50_ncp25' = df5,'n50_ncp50' = df6,'n100_ncp10' = df7, 'n100_ncp25' = df8, 'n100_ncp50' = df9)

#export each data frame to separate sheets in same Excel file
openxlsx::write.xlsx(ncp_dataset_names, file = 'noncentralchisq.xlsx') 

#================================================================================
# CREATING PNG FIGURE

png("Figure2.png", width=17*3.3, height=22.5*3.3, units="cm", res=300)

margin=c(4,4,6,2)  # bottom, left, top, right
par(mfrow=c(3,2), omi=c(0.5,0.5,0,0), mar=margin)                      #set the size of the outer margins
#m = matrix(1:6, nrow=3,ncol=2, byrow = TRUE)
#layout(mat = m, heights = c(0.5,0.5))

# n = 10, ncp = 10 -----------------------------------------------
p_m1 = p_HMC_hat1 #rowSums(p_HMC1)/100
#ARE_m1 = abs(p_m1 - p_real1) / p_real1

# remove LTZ from the figure 2
#saddle point
y_min = floor(log10(min(c(ARE_d1, ARE_f1, ARE_i1, ARE_s1, ARE_m1)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real1)))
x_max = ceiling(max(-log10(p_real1)))

# Saddlepoint
plot(-log10(p_real1), log10(ARE_s1), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real1), log10(ARE_s1), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real1), log10(ARE_m1), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real1), log10(ARE_m1), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real1), log10(ARE_d1), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real1), log10(ARE_d1), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real1), log10(ARE_f1), col = "green", cex = 2, pch = 2)
lines(-log10(p_real1), log10(ARE_f1), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real1), log10(ARE_i1), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real1), log10(ARE_i1), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real1), label = ceiling(-log10(p_real1)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f1, ARE_d1, ARE_s1, ARE_m1, ARE_i1)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='A', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("df")*bold(" = 10, ")*bolditalic("ncp")*bold(" = 10")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# n = 10, ncp = 50 -----------------------------------------------
p_m2 = p_HMC_hat2 #rowSums(p_HMC1)/100
#ARE_m1 = abs(p_m1 - p_real1) / p_real1

# remove LTZ from the figure 2
#saddle point
y_min = floor(log10(min(c(ARE_d2, ARE_f2, ARE_i2, ARE_s2, ARE_m2)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real2)))
x_max = ceiling(max(-log10(p_real2)))

# Saddlepoint
plot(-log10(p_real2), log10(ARE_s2), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real2), log10(ARE_s2), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real2), log10(ARE_m2), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real2), log10(ARE_m2), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real2), log10(ARE_d2), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real2), log10(ARE_d2), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real2), log10(ARE_f2), col = "green", cex = 2, pch = 2)
lines(-log10(p_real2), log10(ARE_f2), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real2), log10(ARE_i2), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real2), log10(ARE_i2), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real2), label = ceiling(-log10(p_real2)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f2, ARE_d2, ARE_s2, ARE_m2, ARE_i2)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='B', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("df")*bold(" = 10, ")*bolditalic("ncp")*bold(" = 50")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# n = 50, ncp = 50 -----------------------------------------------
p_m6 = p_HMC_hat6 #rowSums(p_HMC1)/100
#ARE_m1 = abs(p_m1 - p_real1) / p_real1

# remove LTZ from the figure 2
#saddle point
y_min = floor(log10(min(c(ARE_d6, ARE_f6, ARE_i6, ARE_s6, ARE_m6)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real6)))
x_max = ceiling(max(-log10(p_real6)))

# Saddlepoint
plot(-log10(p_real6), log10(ARE_s6), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real6), log10(ARE_s6), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real6), log10(ARE_m6), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real6), log10(ARE_m6), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real6), log10(ARE_d6), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real6), log10(ARE_d6), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real6), log10(ARE_f6), col = "green", cex = 2, pch = 2)
lines(-log10(p_real6), log10(ARE_f6), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real6), log10(ARE_i6), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real6), log10(ARE_i6), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real6), label = ceiling(-log10(p_real6)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f6, ARE_d6, ARE_s6, ARE_m6, ARE_i6)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='C', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("df")*bold(" = 50, ")*bolditalic("ncp")*bold(" = 50")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# n = 100, ncp = 10 -----------------------------------------------
p_m7 = p_HMC_hat7 #rowSums(p_HMC1)/100
#ARE_m1 = abs(p_m1 - p_real1) / p_real1

# remove LTZ from the figure 2
#saddle point
y_min = floor(log10(min(c(ARE_d7, ARE_f7, ARE_i7, ARE_s7, ARE_m7)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real7)))
x_max = ceiling(max(-log10(p_real7)))

# Saddlepoint
plot(-log10(p_real7), log10(ARE_s7), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real7), log10(ARE_s7), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real7), log10(ARE_m7), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real7), log10(ARE_m7), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real7), log10(ARE_d7), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real7), log10(ARE_d7), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real7), log10(ARE_f7), col = "green", cex = 2, pch = 2)
lines(-log10(p_real7), log10(ARE_f7), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real7), log10(ARE_i7), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real7), log10(ARE_i7), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real7), label = ceiling(-log10(p_real7)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f7, ARE_d7, ARE_s7, ARE_m7, ARE_i7)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='D', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("df")*bold(" = 100, ")*bolditalic("ncp")*bold(" = 10")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# n = 100, ncp = 25 -----------------------------------------------
p_m8 = p_HMC_hat8 #rowSums(p_HMC1)/100
#ARE_m1 = abs(p_m1 - p_real1) / p_real1

# remove LTZ from the figure 2
#saddle point
y_min = floor(log10(min(c(ARE_d8, ARE_f8, ARE_i8, ARE_s8, ARE_m8)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real8)))
x_max = ceiling(max(-log10(p_real8)))

# Saddlepoint
plot(-log10(p_real8), log10(ARE_s8), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real8), log10(ARE_s8), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real8), log10(ARE_m8), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real8), log10(ARE_m8), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real8), log10(ARE_d8), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real8), log10(ARE_d8), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real8), log10(ARE_f8), col = "green", cex = 2, pch = 2)
lines(-log10(p_real8), log10(ARE_f8), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real8), log10(ARE_i8), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real8), log10(ARE_i8), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real8), label = ceiling(-log10(p_real8)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f8, ARE_d8, ARE_s8, ARE_m8, ARE_i8)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

mtext(text='E', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("df")*bold(" = 100, ")*bolditalic("ncp")*bold(" = 25")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

# n = 100, ncp = 50 -----------------------------------------------
p_m9 = p_HMC_hat9 #rowSums(p_HMC1)/100
#ARE_m1 = abs(p_m1 - p_real1) / p_real1

# remove LTZ from the figure 2
#saddle point
y_min = floor(log10(min(c(ARE_d9, ARE_f9, ARE_i9, ARE_s9, ARE_m9)))) #minimum of y axis
x_min = ceiling(min(-log10(p_real9)))
x_max = ceiling(max(-log10(p_real9)))

# Saddlepoint
plot(-log10(p_real9), log10(ARE_s9), 
     xlim = c(x_min+2, x_max-3),
     ylim = c(y_min, 1), 
     #xlab = expression(bold("Order of magnitude of ") * bolditalic("p")*bold("-value")), 
     #ylab = expression(bold("Order of magnitude of relative error")),
     #main = expression(bolditalic("m")*bold(" = 5")),
     ann = F,
     xaxt = "n", 
     yaxt = "n",
     cex.main = 3, 
     cex.lab = 3, 
     cex = 2,
     pch = 0)
lines(-log10(p_real9), log10(ARE_s9), lwd = 3, lty = 4)

#MCMC-CE
points(-log10(p_real9), log10(ARE_m9), col = "blue", cex = 2, pch = 16)
lines(-log10(p_real9), log10(ARE_m9), col = "blue", lwd = 2, lty = 4)

#Davies
points(-log10(p_real9), log10(ARE_d9), col = "purple", cex = 2, pch = 1)
lines(-log10(p_real9), log10(ARE_d9), col = "purple", lwd = 2, lty = 4)
#ind_d1 = min(which(ARE_d1>0.999))
#points(-log10(p_real1)[ind_d1], log10(ARE_d1[ind_d1]), col = "purple", cex = 3, pch = "X")

#Farebrother
points(-log10(p_real9), log10(ARE_f9), col = "green", cex = 2, pch = 2)
lines(-log10(p_real9), log10(ARE_f9), col = "green", lwd = 2, lty = 4)
#ind_f1 = min(which(ARE_f1>0.999))
#points(-log10(p_real1)[ind_f1], log10(ARE_f1[ind_f1])+0.1, col = "green", cex = 3, pch = "X") # "+0.1" is to avoid overlapping with Davies

#Imhof
points(-log10(p_real9), log10(ARE_i9), col = "orange", cex = 2, pch = 5)
lines(-log10(p_real9), log10(ARE_i9), col = "orange", lwd = 2, lty = 4)
#ind_i1 = min(which(ARE_i1>0.999))
#points(-log10(p_real1)[ind_i1], log10(ARE_i1[ind_i1]), col = "orange", cex = 3, pch = "X")

abline(h=1e-3, lty=2, lwd=4, col="red")

axis(1, at = -log10(p_real9), label = ceiling(-log10(p_real9)), 
     font=2,
     cex.axis = 1.43)

y_min = floor(log10(min(c(ARE_f9, ARE_d9, ARE_s9, ARE_m9, ARE_i9)))) #minimum of y axis
y_pos = c(seq(y_min, -2, by=2), -1, 0) #position of label on y axis
axis(2, at = y_pos, labels = c(parse(text=(paste("10^",y_pos[-length(y_pos)], sep = ''))),1), cex.axis = 2, font=2, las=2)

legend(x=-log10(p_real1)[8],y=-7, col = c("blue","black","purple", "green", "orange"), cex = 3, pch = c(16, 0, 1, 2, 5), lty = 4, lwd=3, 
       legend = c("MCMC-CE","Saddlepoint", "Davies","Farebrother","Imhof"), bty = "n")


mtext(text='F', side=3, at=0, line=1, font=2, cex=3)
mtext(text=expression(bolditalic("df")*bold(" = 100, ")*bolditalic("ncp")*bold(" = 50")), side=3, line=1, font=2, cex=3)
mtext(text="Relative error", side=2, line=5, font=2, cex=2)

dev.off()


